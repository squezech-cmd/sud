export type Role = "judge" | "prosecutor" | "advocate" | "witness";

export type Card = {
  id: string;
  title: string;
  text: string;
  used: boolean;
};

export type Player = {
  id: string;
  name: string;
  role: Role | null;
  muted: boolean;
  lastSeen: number;
};

export type LogKind = "system" | "speech" | "hammer" | "card" | "verdict" | "chat" | "fun";

export type LogEntry = {
  t: number;
  text: string;
  kind?: LogKind;
  who?: string;
};

export type Reaction = {
  id: string;
  playerId: string;
  emoji: string;
  t: number;
};

export type Phase = "lobby" | "topic" | "trial" | "verdict";

export type RoomState = {
  phase: Phase;
  topic: string;
  players: Player[];
  speakerId: string | null;
  speakerSince: number | null;
  hands: Record<string, Card[]>;
  log: LogEntry[];
  verdict: "guilty" | "innocent" | null;
  lastHit: { targetId: string; kind: "player" | "button"; t: number } | null;
  handsUp: string[];
  reactions: Reaction[];
  objection: { playerId: string; t: number } | null;
  onBreak: boolean;
  round: number;
};

export const ROLE_LABELS: Record<Role, string> = {
  judge: "Судья",
  prosecutor: "Прокурор",
  advocate: "Адвокат",
  witness: "Свидетель",
};

export const ROLE_COLORS: Record<Role, string> = {
  judge: "#7c3aed",
  prosecutor: "#ef4444",
  advocate: "#3b82f6",
  witness: "#10b981",
};

export const SPEECH_LIMIT_MS = 120_000;

const PROSECUTOR_DECK: Array<{ title: string; text: string }> = [
  { title: "Улика", text: "Найден предмет, прямо указывающий на обвиняемого." },
  { title: "Свидетель обвинения", text: "Некто видел всё своими глазами и готов дать показания." },
  { title: "Запись с камеры", text: "Камера наблюдения зафиксировала подозрительный момент." },
  { title: "Отпечатки пальцев", text: "Экспертиза нашла отпечатки на месте событий." },
  { title: "Мотив", text: "У обвиняемого была веская причина так поступить." },
  { title: "Распечатка переписки", text: "Сообщения раскрывают истинные намерения." },
  { title: "Признание соучастника", text: "Подельник сдал всех и рассказал всё следствию." },
  { title: "Финансовый след", text: "Подозрительный перевод в ту самую ночь. Деньги не врут." },
  { title: "Экспертиза", text: "Независимый эксперт подтверждает версию обвинения." },
  { title: "Орудие преступления", text: "Экземпляр изъят у обвиняемого под кроватью." },
  { title: "Показания очевидца", text: "Очевидец опознал обвиняемого в темноте." },
  { title: "Алиби не сходится", text: "Проверка показала: его «алиби» — блеф." },
];

const ADVOCATE_DECK: Array<{ title: string; text: string }> = [
  { title: "Алиби", text: "Мой подзащитный был совсем в другом месте. Есть подтверждение!" },
  { title: "Свидетель защиты", text: "Уважаемый гражданин подтвердит невиновность." },
  { title: "Сомнительная улика", text: "Эта «улика» могла принадлежать кому угодно." },
  { title: "Ошибка экспертизы", text: "Экспертиза проведена с грубыми нарушениями." },
  { title: "Нет мотива", text: "Зачем бы моему подзащитному это делать? Незачем!" },
  { title: "Провокация", text: "Моего подзащитного подставили. И я знаю кто." },
  { title: "Характеристика", text: "Образцовый гражданин: кормит голубей и переводит бабушек." },
  { title: "Алиби от мамы", text: "Мама говорит, что он был дома и ел суп. Мамы не врут." },
  { title: "Двойник", text: "Это был не он! В городе орудует его точный двойник." },
  { title: "Нечистая совесть", text: "Обвинение само фабрикует улики. Я это докажу!" },
  { title: "След на снегу", text: "Следы ведут в другую сторону. Совпадение?" },
  { title: "Психологическая экспертиза", text: "Обвиняемый просто не способен на такое." },
];

export const REACTIONS = ["👏", "😂", "😱", "🔥", "⚖️", "👻", "🤦", "💯"];

export function dealCards(side: "prosecutor" | "advocate", n = 5): Card[] {
  const deck = side === "prosecutor" ? PROSECUTOR_DECK : ADVOCATE_DECK;
  const shuffled = [...deck].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, n).map((c, i) => ({
    id: `${side}-${Date.now()}-${i}`,
    title: c.title,
    text: c.text,
    used: false,
  }));
}

export function initialState(): RoomState {
  return {
    phase: "lobby",
    topic: "",
    players: [],
    speakerId: null,
    speakerSince: null,
    hands: {},
    log: [{ t: Date.now(), text: "Зал суда открыт. Ожидаем участников…", kind: "system" }],
    verdict: null,
    lastHit: null,
    handsUp: [],
    reactions: [],
    objection: null,
    onBreak: false,
    round: 1,
  };
}

export function pushLog(
  state: RoomState,
  text: string,
  kind: LogKind = "system",
  who?: string
) {
  state.log.push({ t: Date.now(), text, kind, who });
  if (state.log.length > 80) state.log = state.log.slice(-80);
}

export function genCode(): string {
  const chars = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
  let s = "";
  for (let i = 0; i < 4; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return s;
}
