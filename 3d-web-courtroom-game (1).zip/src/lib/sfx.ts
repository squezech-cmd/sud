"use client";

// Tiny synthesized sound effects (no external audio files).
let ctx: AudioContext | null = null;

export function ensureAudio(): AudioContext | null {
  if (typeof window === "undefined") return null;
  try {
    if (!ctx) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      ctx = new AC();
    }
    if (ctx.state === "suspended") void ctx.resume();
    return ctx;
  } catch {
    return null;
  }
}

function noiseBurst(dur: number, gain: number, filterFreq: number) {
  const c = ensureAudio();
  if (!c) return;
  const frames = Math.floor(c.sampleRate * dur);
  const buf = c.createBuffer(1, frames, c.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < frames; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / frames);
  const src = c.createBufferSource();
  src.buffer = buf;
  const filter = c.createBiquadFilter();
  filter.type = "lowpass";
  filter.frequency.value = filterFreq;
  const g = c.createGain();
  g.gain.value = gain;
  src.connect(filter).connect(g).connect(c.destination);
  src.start();
}

function tone(freq: number, dur: number, gain: number, type: OscillatorType = "sine", slideTo?: number) {
  const c = ensureAudio();
  if (!c) return;
  const osc = c.createOscillator();
  osc.type = type;
  const g = c.createGain();
  const now = c.currentTime;
  osc.frequency.setValueAtTime(freq, now);
  if (slideTo) osc.frequency.exponentialRampToValueAtTime(Math.max(20, slideTo), now + dur);
  g.gain.setValueAtTime(0.0001, now);
  g.gain.exponentialRampToValueAtTime(gain, now + 0.008);
  g.gain.exponentialRampToValueAtTime(0.0001, now + dur);
  osc.connect(g).connect(c.destination);
  osc.start(now);
  osc.stop(now + dur + 0.05);
}

export const sfx = {
  bang() {
    tone(180, 0.28, 0.5, "triangle", 55);
    noiseBurst(0.16, 0.35, 1400);
  },
  bell() {
    tone(880, 0.6, 0.28, "sine");
    tone(1320, 0.45, 0.16, "sine");
    tone(220, 0.5, 0.14, "triangle");
  },
  flip() {
    noiseBurst(0.12, 0.22, 3200);
    tone(520, 0.09, 0.1, "square", 720);
  },
  verdict() {
    tone(120, 0.35, 0.5, "triangle", 45);
    noiseBurst(0.2, 0.4, 1200);
    setTimeout(() => tone(100, 0.35, 0.45, "triangle", 40), 220);
    setTimeout(() => tone(90, 0.55, 0.5, "triangle", 35), 460);
    setTimeout(() => noiseBurst(0.35, 0.3, 900), 460);
  },
  pop() {
    tone(660, 0.12, 0.22, "sine", 990);
  },
  whoosh() {
    noiseBurst(0.35, 0.25, 2600);
    tone(300, 0.3, 0.12, "sine", 620);
  },
  objection() {
    tone(220, 0.22, 0.35, "sawtooth", 320);
    setTimeout(() => tone(330, 0.3, 0.3, "sawtooth", 240), 140);
    noiseBurst(0.18, 0.28, 1800);
  },
};
