import { pool } from "@/db";
import type { RoomState } from "@/lib/game";

// Atomically read-modify-write room state using row lock.
export async function withRoom<T>(
  code: string,
  fn: (state: RoomState) => T | Promise<T>
): Promise<{ ok: true; state: RoomState; result: T } | { ok: false; error: string }> {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const res = await client.query(
      "SELECT id, state FROM rooms WHERE code = $1 FOR UPDATE",
      [code.toUpperCase()]
    );
    if (res.rowCount === 0) {
      await client.query("ROLLBACK");
      return { ok: false, error: "Комната не найдена" };
    }
    const state = res.rows[0].state as RoomState;
    const result = await fn(state);
    await client.query(
      "UPDATE rooms SET state = $1, updated_at = now() WHERE id = $2",
      [JSON.stringify(state), res.rows[0].id]
    );
    await client.query("COMMIT");
    return { ok: true, state, result };
  } catch (e) {
    await client.query("ROLLBACK").catch(() => {});
    throw e;
  } finally {
    client.release();
  }
}

export async function readRoom(code: string): Promise<RoomState | null> {
  const res = await pool.query("SELECT state FROM rooms WHERE code = $1", [
    code.toUpperCase(),
  ]);
  if (res.rowCount === 0) return null;
  return res.rows[0].state as RoomState;
}
