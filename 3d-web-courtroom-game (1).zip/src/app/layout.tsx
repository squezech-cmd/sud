import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Народный суд 3D — голосовая пати-игра",
  description:
    "3D-игра в суд: судья, прокурор и адвокат спорят голосом. Судья мутит молотком!",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru">
      <body className="bg-[#120a1c] text-amber-50 antialiased">{children}</body>
    </html>
  );
}
