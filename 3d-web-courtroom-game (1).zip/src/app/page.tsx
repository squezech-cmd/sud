"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

type CaseRow = {
  id: number;
  roomCode: string;
  topic: string;
  verdict: string;
  players: { name: string; role: string | null }[];
  createdAt: string;
};

const ROLE_LABELS: Record<string, string> = {
  judge: "Судья",
  prosecutor: "Прокурор",
  advocate: "Адвокат",
  witness: "Свидетель",
};

export default function Home() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [cases, setCases] = useState<CaseRow[]>([]);

  useEffect(() => {
    const saved = sessionStorage.getItem("court-name");
    if (saved) setName(saved);
    fetch("/api/cases", { cache: "no-store" })
      .then((r) => r.json())
      .then((d) => setCases(d.cases || []))
      .catch(() => {});
  }, []);

  async function createRoom() {
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/rooms", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Ошибка");
      sessionStorage.setItem(`court-player-${data.code}`, data.playerId);
      sessionStorage.setItem("court-name", name);
      router.push(`/room/${data.code}`);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Ошибка");
      setBusy(false);
    }
  }

  async function joinRoom() {
    setBusy(true);
    setError(null);
    try {
      const c = code.trim().toUpperCase();
      const res = await fetch(`/api/rooms/${c}/join`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Ошибка");
      sessionStorage.setItem(`court-player-${data.code}`, data.playerId);
      sessionStorage.setItem("court-name", name);
      router.push(`/room/${data.code}`);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Ошибка");
      setBusy(false);
    }
  }

  const nameOk = name.trim().length > 0;

  return (
    <main className="min-h-screen bg-gradient-to-b from-[#1a1026] via-[#241435] to-[#120a1c] text-amber-50">
      <div className="max-w-5xl mx-auto px-6 py-12">
        {/* hero */}
        <div className="text-center">
          <div className="text-8xl mb-4">⚖️</div>
          <h1 className="text-6xl sm:text-7xl font-black tracking-tight bg-gradient-to-r from-amber-300 via-orange-300 to-amber-400 bg-clip-text text-transparent">
            НАРОДНЫЙ СУД 3D
          </h1>
          <p className="mt-4 text-amber-200/75 text-lg max-w-2xl mx-auto">
            Пати-игра для троих друзей: судья, прокурор и адвокат спорят голосом в 3D-зале суда.
            Судья мутит молотком, даёт слово ударом по кнопке, а адвокат кричит «ПРОТЕСТ!»
          </p>
        </div>

        {/* join card */}
        <div className="mt-10 rounded-3xl bg-white/5 border border-white/10 backdrop-blur-xl p-8 shadow-2xl max-w-2xl mx-auto">
          <div>
            <label className="block text-sm text-amber-200/70 mb-1">Ваше имя</label>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              maxLength={20}
              placeholder="Например, Фемида"
              className="w-full rounded-2xl bg-black/30 border border-white/15 px-5 py-4 outline-none focus:border-amber-400 placeholder:text-white/30 text-lg"
            />
          </div>

          <button
            disabled={!nameOk || busy}
            onClick={createRoom}
            className="mt-4 w-full rounded-2xl bg-gradient-to-r from-amber-400 to-orange-500 text-black font-black py-4 text-lg hover:brightness-110 transition disabled:opacity-40 disabled:cursor-not-allowed"
          >
            🏛️ Создать зал суда
          </button>

          <div className="flex items-center gap-3 text-white/30 text-xs my-5">
            <div className="h-px bg-white/10 flex-1" /> ИЛИ{" "}
            <div className="h-px bg-white/10 flex-1" />
          </div>

          <div className="flex gap-2">
            <input
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              maxLength={4}
              placeholder="КОД"
              className="w-32 rounded-2xl bg-black/30 border border-white/15 px-4 py-4 outline-none focus:border-amber-400 text-center tracking-widest font-mono uppercase placeholder:text-white/30 text-lg"
            />
            <button
              disabled={!nameOk || code.trim().length !== 4 || busy}
              onClick={joinRoom}
              className="flex-1 rounded-2xl bg-white/10 border border-white/15 font-bold py-4 hover:bg-white/20 transition disabled:opacity-40 disabled:cursor-not-allowed"
            >
              Войти в зал по коду
            </button>
          </div>

          {error && (
            <div className="mt-4 rounded-2xl bg-red-500/15 border border-red-500/40 text-red-200 text-sm px-4 py-3">
              {error}
            </div>
          )}
        </div>

        {/* how to play with friends */}
        <section className="mt-16">
          <h2 className="text-3xl font-black text-center">Как играть с друзьями</h2>
          <div className="mt-6 grid sm:grid-cols-3 gap-4">
            {[
              {
                n: "1",
                title: "Создайте зал",
                text: "Нажмите «Создать зал суда» — появится 4-значный код вроде K7QP. Это ваш частный зал.",
              },
              {
                n: "2",
                title: "Позовите своих",
                text: "Отправьте друзьям ссылку на страницу зала или сам код. Они заходят с телефона или ПК, вводят имя и код.",
              },
              {
                n: "3",
                title: "Включите голос",
                text: "В зале нажмите «🔇 Включить голос» и разрешите доступ к микрофону. Без этого шага голос не работает!",
              },
            ].map((s) => (
              <div key={s.n} className="rounded-2xl bg-white/5 border border-white/10 p-5">
                <div className="w-9 h-9 rounded-full bg-amber-400 text-black font-black flex items-center justify-center">
                  {s.n}
                </div>
                <div className="mt-3 font-bold text-lg">{s.title}</div>
                <div className="text-sm text-white/60 mt-1 leading-relaxed">{s.text}</div>
              </div>
            ))}
          </div>
          <div className="mt-4 rounded-2xl bg-amber-500/10 border border-amber-400/25 p-4 text-sm text-amber-100/90">
            💡 Нужно минимум трое: <b>судья</b>, <b>прокурор</b> и <b>адвокат</b>. Больше друзей?
            Остальные станут свидетелями — им тоже можно говорить, показывать реакции и просить слово.
          </div>
        </section>

        {/* roles */}
        <section className="mt-16">
          <h2 className="text-3xl font-black text-center">Роли</h2>
          <div className="mt-6 grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              {
                icon: "🧑‍⚖️",
                color: "#7c3aed",
                name: "Судья",
                text: "Бьёт молотком по игрокам (мут), даёт слово ударом по красной кнопке, объявляет перерыв и выносит вердикт.",
              },
              {
                icon: "🔥",
                color: "#ef4444",
                name: "Прокурор",
                text: "Задаёт тему дела и получает колоду улик: запись с камеры, мотив, экспертиза, признание соучастника…",
              },
              {
                icon: "🛡️",
                color: "#3b82f6",
                name: "Адвокат",
                text: "Защищает обвиняемого карточками алиби: «Алиби от мамы», «Двойник», «Ошибка экспертизы» и, конечно, «Протест!»",
              },
              {
                icon: "👀",
                color: "#10b981",
                name: "Свидетель",
                text: "Свободная роль для всех остальных. Слушает, кидает реакции, поднимает руку и может перевернуть дело словом.",
              },
            ].map((r) => (
              <div key={r.name} className="rounded-2xl bg-white/5 border border-white/10 p-5">
                <div className="text-4xl">{r.icon}</div>
                <div className="mt-2 font-bold text-lg" style={{ color: r.color }}>
                  {r.name}
                </div>
                <div className="text-sm text-white/60 mt-1 leading-relaxed">{r.text}</div>
              </div>
            ))}
          </div>
        </section>

        {/* archive */}
        <section className="mt-16">
          <h2 className="text-3xl font-black text-center">📜 Архив последних дел</h2>
          {cases.length === 0 ? (
            <p className="text-center text-white/50 mt-4">
              Ещё ни одного вердикта. Первое дело ждёт вас!
            </p>
          ) : (
            <div className="mt-6 grid sm:grid-cols-2 gap-3">
              {cases.slice(0, 6).map((c) => (
                <div key={c.id} className="rounded-2xl bg-white/5 border border-white/10 p-4 flex gap-3">
                  <div className="text-3xl">{c.verdict === "guilty" ? "⛓️" : "🕊️"}</div>
                  <div className="flex-1">
                    <div className="font-semibold">{c.topic}</div>
                    <div className="text-[11px] text-white/45 mt-1">
                      зал {c.roomCode} ·{" "}
                      {new Date(c.createdAt).toLocaleString("ru-RU", {
                        day: "2-digit",
                        month: "short",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </div>
                    <div className="text-[11px] text-white/60 mt-1">
                      {(c.players || [])
                        .map((p) => `${p.name} — ${p.role ? ROLE_LABELS[p.role] : "—"}`)
                        .join(" · ")}
                    </div>
                  </div>
                  <div
                    className={`text-[10px] font-bold px-2 py-1 h-fit rounded-lg ${
                      c.verdict === "guilty"
                        ? "bg-red-500/20 text-red-200"
                        : "bg-emerald-500/20 text-emerald-200"
                    }`}
                  >
                    {c.verdict === "guilty" ? "ВИНОВЕН" : "НЕВИНОВЕН"}
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* features */}
        <section className="mt-16 grid grid-cols-2 lg:grid-cols-4 gap-3 text-center text-xs text-amber-200/70">
          {[
            { icon: "🔨", text: "Молоток судьи мутит игроков прямо в 3D" },
            { icon: "🃏", text: "Коллоды улик и алиби для сторон" },
            { icon: "🎙️", text: "Голосовой чат WebRTC прямо в браузере" },
            { icon: "👁️", text: "Вид от первого лица: WASD и обзор мышью" },
            { icon: "🚨", text: "Кнопка «ПРОТЕСТ!» с эффектом и звуком" },
            { icon: "👏", text: "Реакции, поднятые руки и текстовый чат" },
            { icon: "☕", text: "Перерыв от судьи и таймер речи" },
            { icon: "📜", text: "Архив дел: все вердикты сохраняются" },
          ].map((f) => (
            <div key={f.text} className="rounded-2xl bg-white/5 border border-white/10 p-4">
              <div className="text-2xl mb-2">{f.icon}</div>
              {f.text}
            </div>
          ))}
        </section>

        <footer className="mt-16 text-center text-xs text-white/35 pb-8">
          Народный суд 3D · играйте честно, спорьте громко, молоток — аккуратнее 🔨
        </footer>
      </div>
    </main>
  );
}
