"use client";

import dynamic from "next/dynamic";
import { useParams } from "next/navigation";

const GameClient = dynamic(() => import("@/components/GameClient"), {
  ssr: false,
  loading: () => (
    <div className="min-h-screen bg-[#120a1c] text-amber-200 flex items-center justify-center">
      <div className="text-center">
        <div className="text-6xl animate-bounce">⚖️</div>
        <p className="mt-4">Загружаем зал суда…</p>
      </div>
    </div>
  ),
});

export default function RoomPage() {
  const params = useParams<{ code: string }>();
  const code = (params.code || "").toUpperCase();
  return <GameClient code={code} />;
}
