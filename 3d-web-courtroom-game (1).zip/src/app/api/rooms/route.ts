import { NextResponse } from "next/server";
import { db } from "@/db";
import { rooms } from "@/db/schema";
import { genCode, initialState, pushLog, type Player } from "@/lib/game";

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const name = String(body.name || "").trim().slice(0, 20);
  if (!name) {
    return NextResponse.json({ error: "Введите имя" }, { status: 400 });
  }

  const playerId = crypto.randomUUID();
  const state = initialState();
  const player: Player = {
    id: playerId,
    name,
    role: null,
    muted: false,
    lastSeen: Date.now(),
  };
  state.players.push(player);
  pushLog(state, `${name} вошёл(ла) в зал суда`);

  // retry on rare code collision
  for (let attempt = 0; attempt < 5; attempt++) {
    const code = genCode();
    try {
      await db.insert(rooms).values({ code, state });
      return NextResponse.json({ code, playerId });
    } catch {
      // collision, retry
    }
  }
  return NextResponse.json({ error: "Не удалось создать комнату" }, { status: 500 });
}
