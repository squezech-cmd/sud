import { NextResponse } from "next/server";
import { and, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import { signals } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function POST(
  req: Request,
  { params }: { params: Promise<{ code: string }> }
) {
  const { code } = await params;
  const body = await req.json().catch(() => ({}));
  const { fromId, toId, kind, payload } = body as {
    fromId?: string;
    toId?: string;
    kind?: string;
    payload?: unknown;
  };
  if (!fromId || !toId || !kind || payload === undefined) {
    return NextResponse.json({ error: "Неполные данные" }, { status: 400 });
  }
  await db.insert(signals).values({
    roomCode: code.toUpperCase(),
    fromId,
    toId,
    kind,
    payload: payload as object,
  });
  return NextResponse.json({ ok: true });
}

export async function GET(
  req: Request,
  { params }: { params: Promise<{ code: string }> }
) {
  const { code } = await params;
  const url = new URL(req.url);
  const playerId = url.searchParams.get("playerId") || "";
  const after = Number(url.searchParams.get("after") || 0);

  const rows = await db
    .select()
    .from(signals)
    .where(
      and(
        eq(signals.roomCode, code.toUpperCase()),
        eq(signals.toId, playerId),
        gt(signals.id, after)
      )
    )
    .orderBy(signals.id)
    .limit(100);

  return NextResponse.json({ signals: rows });
}
