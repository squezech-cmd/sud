import { NextResponse } from "next/server";
import { withRoom } from "@/lib/room-server";
import { pushLog } from "@/lib/game";

export async function POST(
  req: Request,
  { params }: { params: Promise<{ code: string }> }
) {
  const { code } = await params;
  const body = await req.json().catch(() => ({}));
  const name = String(body.name || "").trim().slice(0, 20);
  if (!name) {
    return NextResponse.json({ error: "Введите имя" }, { status: 400 });
  }

  const playerId = crypto.randomUUID();
  const res = await withRoom(code, (state) => {
    if (state.players.length >= 8) {
      return { error: "Комната заполнена (максимум 8)" };
    }
    state.players.push({
      id: playerId,
      name,
      role: null,
      muted: false,
      lastSeen: Date.now(),
    });
    pushLog(state, `${name} вошёл(ла) в зал суда`);
    return { error: null };
  });

  if (!res.ok) return NextResponse.json({ error: res.error }, { status: 404 });
  if (res.result.error)
    return NextResponse.json({ error: res.result.error }, { status: 400 });
  return NextResponse.json({ code: code.toUpperCase(), playerId });
}
