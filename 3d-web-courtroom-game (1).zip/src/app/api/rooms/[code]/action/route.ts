import { NextResponse } from "next/server";
import { db } from "@/db";
import { cases } from "@/db/schema";
import { withRoom } from "@/lib/room-server";
import {
  dealCards,
  pushLog,
  REACTIONS,
  ROLE_LABELS,
  type Role,
  type RoomState,
} from "@/lib/game";

export const dynamic = "force-dynamic";

type ActionBody = {
  playerId?: string;
  type?: string;
  role?: Role;
  topic?: string;
  targetId?: string;
  cardId?: string;
  verdict?: "guilty" | "innocent";
  text?: string;
  emoji?: string;
};

function applyAction(state: RoomState, body: ActionBody): string | null {
  const me = state.players.find((p) => p.id === body.playerId);
  if (!me) return "Вы не в этой комнате";

  switch (body.type) {
    case "chooseRole": {
      if (state.phase !== "lobby") return "Роли выбираются только в лобби";
      const role = body.role;
      if (!role || !["judge", "prosecutor", "advocate", "witness"].includes(role))
        return "Неверная роль";
      if (role !== "witness" && state.players.some((p) => p.role === role && p.id !== me.id))
        return `Роль «${ROLE_LABELS[role]}» уже занята`;
      me.role = role;
      pushLog(state, `${me.name} — теперь ${ROLE_LABELS[role]}`, "system");
      return null;
    }
    case "start": {
      if (state.phase !== "lobby") return "Игра уже началась";
      const haveJudge = state.players.some((p) => p.role === "judge");
      const haveProsecutor = state.players.some((p) => p.role === "prosecutor");
      const haveAdvocate = state.players.some((p) => p.role === "advocate");
      if (state.players.length < 3) return "Нужно минимум 3 игрока";
      if (!haveJudge || !haveProsecutor || !haveAdvocate)
        return "Нужны судья, прокурор и адвокат";
      for (const p of state.players) if (!p.role) p.role = "witness";
      state.phase = "topic";
      pushLog(state, "⚖️ Заседание начинается! Прокурор формулирует дело…", "system");
      return null;
    }
    case "setTopic": {
      if (state.phase !== "topic") return "Сейчас нельзя задать тему";
      if (me.role !== "prosecutor") return "Тему дела задаёт прокурор";
      const topic = String(body.topic || "").trim().slice(0, 120);
      if (!topic) return "Опишите дело";
      state.topic = topic;
      const prosecutor = state.players.find((p) => p.role === "prosecutor");
      const advocate = state.players.find((p) => p.role === "advocate");
      if (prosecutor) state.hands[prosecutor.id] = dealCards("prosecutor");
      if (advocate) state.hands[advocate.id] = dealCards("advocate");
      state.phase = "trial";
      state.speakerId = prosecutor?.id ?? null;
      state.speakerSince = Date.now();
      state.onBreak = false;
      pushLog(state, `📋 Дело: «${topic}». Карточки розданы. Слово — обвинению!`, "system");
      return null;
    }
    case "hammerPlayer": {
      if (me.role !== "judge") return "Молоток есть только у судьи";
      const target = state.players.find((p) => p.id === body.targetId);
      if (!target) return "Игрок не найден";
      if (target.id === me.id) return "Судья не бьёт себя молотком";
      target.muted = !target.muted;
      if (target.muted && state.speakerId === target.id) {
        state.speakerId = null;
        state.speakerSince = null;
      }
      state.lastHit = { targetId: target.id, kind: "player", t: Date.now() };
      pushLog(
        state,
        target.muted
          ? `🔨 Судья молотком заглушил ${target.name}!`
          : `🔨 Судья вернул(а) голос ${target.name}`,
        "hammer"
      );
      return null;
    }
    case "giveFloor": {
      if (me.role !== "judge") return "Слово даёт только судья";
      const candidates = state.players.filter((p) => p.role !== "judge" && !p.muted);
      if (candidates.length === 0) return "Некому давать слово — все замучены";
      let target = candidates.find((p) => p.id === body.targetId);
      if (!target) {
        const idx = candidates.findIndex((p) => p.id === state.speakerId);
        target = candidates[(idx + 1) % candidates.length];
      }
      state.speakerId = target.id;
      state.speakerSince = Date.now();
      state.handsUp = state.handsUp.filter((id) => id !== target.id);
      state.lastHit = { targetId: "button", kind: "button", t: Date.now() };
      pushLog(state, `🔔 Судья бьёт по кнопке: слово — ${target.name}!`, "system");
      return null;
    }
    case "endSpeech": {
      if (me.role !== "judge" && me.id !== state.speakerId) return "Вам не дано слово";
      const speaker = state.players.find((p) => p.id === state.speakerId);
      state.speakerId = null;
      state.speakerSince = null;
      if (speaker) pushLog(state, `Выступление ${speaker.name} завершено.`, "system");
      return null;
    }
    case "playCard": {
      if (state.phase !== "trial") return "Карточки играются во время заседания";
      const hand = state.hands[me.id];
      if (!hand) return "У вас нет карточек";
      const card = hand.find((c) => c.id === body.cardId);
      if (!card || card.used) return "Карточка недоступна";
      card.used = true;
      const roleLabel = ROLE_LABELS[me.role ?? "witness"];
      pushLog(
        state,
        `🃏 ${roleLabel} ${me.name} выкладывает «${card.title}»: ${card.text}`,
        "card"
      );
      if (card.title === "Протест!") {
        state.objection = { playerId: me.id, t: Date.now() };
        pushLog(state, `🚨 ПРОТЕСТ! ${me.name} оспаривает сказанное.`, "fun");
      }
      return null;
    }
    case "objection": {
      if (state.phase !== "trial") return "Протестовать можно только на заседании";
      if (me.role === "judge") return "Судья не протестует сам на себя";
      state.objection = { playerId: me.id, t: Date.now() };
      pushLog(state, `🚨 ПРОТЕСТ! ${me.name} возражает!`, "fun");
      return null;
    }
    case "raiseHand": {
      if (me.role === "judge") return "Судья и так главный здесь";
      if (state.handsUp.includes(me.id)) {
        state.handsUp = state.handsUp.filter((id) => id !== me.id);
        pushLog(state, `${me.name} опустил(а) руку.`, "fun");
      } else {
        state.handsUp.push(me.id);
        pushLog(state, `✋ ${me.name} просит слово.`, "fun");
      }
      return null;
    }
    case "reaction": {
      const emoji = REACTIONS.includes(String(body.emoji)) ? String(body.emoji) : "👏";
      state.reactions.push({
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        playerId: me.id,
        emoji,
        t: Date.now(),
      });
      if (state.reactions.length > 40) state.reactions = state.reactions.slice(-40);
      return null;
    }
    case "break": {
      if (me.role !== "judge") return "Перерыв объявляет только судья";
      state.onBreak = !state.onBreak;
      if (state.onBreak) {
        state.speakerId = null;
        state.speakerSince = null;
        pushLog(state, "☕ Судья объявляет перерыв. Кофе, печеньки, обмен мнениями.", "fun");
      } else {
        pushLog(state, "⚖️ Перерыв окончен. Заседание продолжается!", "system");
      }
      return null;
    }
    case "chat": {
      const text = String(body.text || "").trim().slice(0, 160);
      if (!text) return "Пустое сообщение";
      pushLog(state, text, "chat", me.name);
      return null;
    }
    case "verdict": {
      if (me.role !== "judge") return "Вердикт выносит только судья";
      if (state.phase !== "trial") return "Сейчас нельзя вынести вердикт";
      if (body.verdict !== "guilty" && body.verdict !== "innocent") return "Неверный вердикт";
      state.verdict = body.verdict;
      state.phase = "verdict";
      state.speakerId = null;
      state.speakerSince = null;
      pushLog(
        state,
        body.verdict === "guilty"
          ? "⚖️ ВЕРДИКТ: ВИНОВЕН! Прокурор торжествует."
          : "⚖️ ВЕРДИКТ: НЕВИНОВЕН! Адвокат ликует.",
        "verdict"
      );
      return "ARCHIVE";
    }
    case "restart": {
      if (state.phase !== "verdict") return "Перезапуск доступен после вердикта";
      state.phase = "topic";
      state.topic = "";
      state.hands = {};
      state.verdict = null;
      state.speakerId = null;
      state.speakerSince = null;
      state.onBreak = false;
      state.objection = null;
      state.handsUp = [];
      state.round += 1;
      for (const p of state.players) p.muted = false;
      pushLog(state, `🔄 Дело №${state.round}. Прокурор, ваш выход…`, "system");
      return null;
    }
    default:
      return "Неизвестное действие";
  }
}

export async function POST(
  req: Request,
  { params }: { params: Promise<{ code: string }> }
) {
  const { code } = await params;
  const body = (await req.json().catch(() => ({}))) as ActionBody;

  const archive: {
    data: { topic: string; verdict: string; players: unknown[] } | null;
  } = { data: null };

  const res = await withRoom(code, (state) => {
    const result = applyAction(state, body);
    if (result === "ARCHIVE") {
      archive.data = {
        topic: state.topic,
        verdict: state.verdict ?? "unknown",
        players: state.players.map((p) => ({ name: p.name, role: p.role })),
      };
      return null;
    }
    return result;
  });

  if (!res.ok) return NextResponse.json({ error: res.error }, { status: 404 });
  if (res.result) return NextResponse.json({ error: res.result }, { status: 400 });

  if (archive.data) {
    try {
      await db.insert(cases).values({
        roomCode: code.toUpperCase(),
        topic: archive.data.topic,
        verdict: archive.data.verdict,
        players: archive.data.players as object,
      });
    } catch {
      // archive is non-critical
    }
  }

  return NextResponse.json({ state: res.state });
}
