import { NextResponse } from "next/server";
import { withRoom } from "@/lib/room-server";
import { pushLog } from "@/lib/game";

export const dynamic = "force-dynamic";

export async function GET(
  req: Request,
  { params }: { params: Promise<{ code: string }> }
) {
  const { code } = await params;
  const url = new URL(req.url);
  const playerId = url.searchParams.get("playerId") || "";

  const res = await withRoom(code, (state) => {
    const now = Date.now();
    const me = state.players.find((p) => p.id === playerId);
    if (me) me.lastSeen = now;

    // prune players silent for > 25s (only in lobby, keep roles stable in trial)
    const stale = state.players.filter(
      (p) => now - p.lastSeen > 25_000 && p.id !== playerId
    );
    if (stale.length > 0 && state.phase === "lobby") {
      for (const p of stale) pushLog(state, `${p.name} покинул(а) зал`);
      state.players = state.players.filter((p) => now - p.lastSeen <= 25_000 || p.id === playerId);
      if (state.speakerId && !state.players.some((p) => p.id === state.speakerId)) {
        state.speakerId = null;
      }
    }
  });

  if (!res.ok) return NextResponse.json({ error: res.error }, { status: 404 });
  return NextResponse.json({ state: res.state });
}
