import { NextResponse } from "next/server";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { cases } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db
    .select()
    .from(cases)
    .orderBy(desc(cases.id))
    .limit(12);
  return NextResponse.json({ cases: rows });
}
