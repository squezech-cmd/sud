"use client";

import { useEffect, useRef, useState } from "react";

export type VoiceStatus = "off" | "connecting" | "live" | "denied";

type SignalRow = {
  id: number;
  fromId: string;
  toId: string;
  kind: string;
  payload: unknown;
};

const RTC_CONFIG: RTCConfiguration = {
  iceServers: [
    { urls: ["stun:stun.l.google.com:19302", "stun:stun1.l.google.com:19302"] },
  ],
};

/**
 * Mesh WebRTC voice chat.
 * Voice is only started when the user explicitly enables it (a click),
 * which is required by browsers for microphone access anyway.
 * If mic is denied the user still joins in listen-only mode.
 */
export function useVoiceChat(opts: {
  code: string;
  playerId: string | null;
  peerIds: string[];
  enabled: boolean;
  micOn: boolean;
  judgeMutedMe: boolean;
  judgeMutedIds: string[];
  masterVolume: number;
}) {
  const { code, playerId, enabled, micOn, judgeMutedMe, masterVolume } = opts;
  const peerKey = opts.peerIds.slice().sort().join(",");
  const mutedKey = opts.judgeMutedIds.slice().sort().join(",");

  const [micState, setMicState] = useState<"idle" | "ready" | "denied">("idle");
  const [connectedIds, setConnectedIds] = useState<string[]>([]);

  const streamRef = useRef<MediaStream | null>(null);
  const pcsRef = useRef<Map<string, RTCPeerConnection>>(new Map());
  const audiosRef = useRef<Map<string, HTMLAudioElement>>(new Map());
  const cursorRef = useRef(0);
  const pendingIceRef = useRef<Map<string, RTCIceCandidateInit[]>>(new Map());

  /* ---- microphone, only after explicit enable ---- */
  useEffect(() => {
    if (!enabled || !playerId) return;
    let cancelled = false;
    (async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        setMicState("ready");
      } catch {
        if (!cancelled) setMicState("denied");
      }
    })();
    return () => {
      cancelled = true;
      streamRef.current?.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    };
  }, [enabled, playerId]);

  /* ---- tear down everything when voice is turned off ---- */
  useEffect(() => {
    if (enabled) return;
    pcsRef.current.forEach((pc) => pc.close());
    pcsRef.current.clear();
    audiosRef.current.forEach((a) => {
      a.pause();
      a.srcObject = null;
    });
    audiosRef.current.clear();
    setConnectedIds([]);
    setMicState("idle");
  }, [enabled]);

  /* ---- local mic enabled state (user toggle AND judge mute) ---- */
  useEffect(() => {
    const stream = streamRef.current;
    if (!stream) return;
    const active = micOn && !judgeMutedMe;
    stream.getAudioTracks().forEach((t) => (t.enabled = active));
  }, [micOn, judgeMutedMe, micState]);

  /* ---- master volume + judge-mute of remote peers ---- */
  useEffect(() => {
    const mutedSet = new Set(mutedKey.split(",").filter(Boolean));
    audiosRef.current.forEach((audio, id) => {
      audio.muted = mutedSet.has(id);
      audio.volume = Math.max(0, Math.min(1, masterVolume / 100));
    });
  }, [mutedKey, masterVolume, connectedIds, micState]);

  /* ---- peer connections + signaling poll ---- */
  useEffect(() => {
    if (!playerId || !enabled || micState === "idle") return;
    let stopped = false;

    const sendSignal = async (toId: string, kind: string, payload: unknown) => {
      await fetch(`/api/rooms/${code}/signal`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fromId: playerId, toId, kind, payload }),
      }).catch(() => {});
    };

    const getAudio = (peerId: string) => {
      let audio = audiosRef.current.get(peerId);
      if (!audio) {
        audio = new Audio();
        audio.autoplay = true;
        audio.volume = Math.max(0, Math.min(1, masterVolume / 100));
        audiosRef.current.set(peerId, audio);
      }
      return audio;
    };

    const makePc = (peerId: string) => {
      const pc = new RTCPeerConnection(RTC_CONFIG);
      pcsRef.current.set(peerId, pc);
      const stream = streamRef.current;
      if (stream && stream.getAudioTracks().length > 0) {
        stream.getTracks().forEach((t) => pc.addTrack(t, stream));
      } else {
        // listen-only: still receive others
        pc.addTransceiver("audio", { direction: "recvonly" });
      }
      pc.onicecandidate = (e) => {
        if (e.candidate) void sendSignal(peerId, "ice", e.candidate.toJSON());
      };
      pc.ontrack = (e) => {
        const audio = getAudio(peerId);
        audio.srcObject = e.streams[0];
        void audio.play().catch(() => {});
      };
      pc.onconnectionstatechange = () => {
        if (pc.connectionState === "connected") {
          setConnectedIds((prev) => (prev.includes(peerId) ? prev : [...prev, peerId]));
        }
        if (["failed", "closed", "disconnected"].includes(pc.connectionState)) {
          setConnectedIds((prev) => prev.filter((x) => x !== peerId));
          if (pc.connectionState === "failed") {
            pc.close();
            pcsRef.current.delete(peerId);
          }
        }
      };
      return pc;
    };

    const flushIce = async (peerId: string, pc: RTCPeerConnection) => {
      const pending = pendingIceRef.current.get(peerId) || [];
      pendingIceRef.current.delete(peerId);
      for (const c of pending) await pc.addIceCandidate(c).catch(() => {});
    };

    const peers = peerKey.split(",").filter(Boolean);
    for (const peerId of peers) {
      if (peerId === playerId || pcsRef.current.has(peerId)) continue;
      if (playerId < peerId) {
        const pc = makePc(peerId);
        (async () => {
          const offer = await pc.createOffer();
          await pc.setLocalDescription(offer);
          await sendSignal(peerId, "offer", offer);
        })().catch(() => {});
      }
    }

    const peerSet = new Set(peers);
    pcsRef.current.forEach((pc, id) => {
      if (!peerSet.has(id)) {
        pc.close();
        pcsRef.current.delete(id);
        const audio = audiosRef.current.get(id);
        if (audio) {
          audio.pause();
          audio.srcObject = null;
          audiosRef.current.delete(id);
        }
        setConnectedIds((prev) => prev.filter((x) => x !== id));
      }
    });

    const poll = async () => {
      if (stopped) return;
      try {
        const res = await fetch(
          `/api/rooms/${code}/signal?playerId=${playerId}&after=${cursorRef.current}`,
          { cache: "no-store" }
        );
        const data = await res.json();
        const rows: SignalRow[] = data.signals || [];
        for (const row of rows) {
          cursorRef.current = Math.max(cursorRef.current, row.id);
          const peerId = row.fromId;
          if (row.kind === "offer") {
            const existing = pcsRef.current.get(peerId);
            if (existing) {
              existing.close();
              pcsRef.current.delete(peerId);
            }
            const pc = makePc(peerId);
            await pc.setRemoteDescription(row.payload as RTCSessionDescriptionInit);
            await flushIce(peerId, pc);
            const answer = await pc.createAnswer();
            await pc.setLocalDescription(answer);
            await sendSignal(peerId, "answer", answer);
          } else if (row.kind === "answer") {
            const pc = pcsRef.current.get(peerId);
            if (pc && pc.signalingState === "have-local-offer") {
              await pc.setRemoteDescription(row.payload as RTCSessionDescriptionInit);
              await flushIce(peerId, pc);
            }
          } else if (row.kind === "ice") {
            const pc = pcsRef.current.get(peerId);
            if (pc && pc.remoteDescription) {
              await pc.addIceCandidate(row.payload as RTCIceCandidateInit).catch(() => {});
            } else {
              const list = pendingIceRef.current.get(peerId) || [];
              list.push(row.payload as RTCIceCandidateInit);
              pendingIceRef.current.set(peerId, list);
            }
          }
        }
      } catch {
        /* network hiccup */
      }
    };

    const interval = setInterval(poll, 1500);
    void poll();
    return () => {
      stopped = true;
      clearInterval(interval);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [playerId, enabled, micState, peerKey, code]);

  const status: VoiceStatus = !enabled
    ? "off"
    : micState === "denied"
    ? "denied"
    : connectedIds.length > 0
    ? "live"
    : "connecting";

  return { status, connectedIds, micReady: micState === "ready" };
}
