"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import CourtScene from "@/components/CourtScene";
import { useVoiceChat } from "@/components/useVoiceChat";
import { sfx } from "@/lib/sfx";
import {
  REACTIONS,
  ROLE_COLORS,
  ROLE_LABELS,
  SPEECH_LIMIT_MS,
  type Role,
  type RoomState,
} from "@/lib/game";

type CaseRow = {
  id: number;
  roomCode: string;
  topic: string;
  verdict: string;
  players: { name: string; role: string | null }[];
  createdAt: string;
};

export default function GameClient({ code }: { code: string }) {
  const router = useRouter();
  const [playerId, setPlayerId] = useState<string | null>(null);
  const [state, setState] = useState<RoomState | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [topicDraft, setTopicDraft] = useState("");
  const [chatDraft, setChatDraft] = useState("");
  const [joining, setJoining] = useState(false);

  // voice + view settings
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [micOn, setMicOn] = useState(true);
  const [masterVolume, setMasterVolume] = useState(80);
  const [firstPerson, setFirstPerson] = useState(false);
  const [showHelp, setShowHelp] = useState(false);
  const [showCases, setShowCases] = useState(false);
  const [cases, setCases] = useState<CaseRow[] | null>(null);
  const [now, setNow] = useState(Date.now());

  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const sfxRef = useRef<{ hit: number; obj: number; verdict: string | null }>({
    hit: 0,
    obj: 0,
    verdict: null,
  });

  useEffect(() => {
    const stored = sessionStorage.getItem(`court-player-${code}`);
    if (stored) setPlayerId(stored);
    else setJoining(true);
  }, [code]);

  // clock for speech timer / reaction fade
  useEffect(() => {
    const iv = setInterval(() => setNow(Date.now()), 500);
    return () => clearInterval(iv);
  }, []);

  // poll room state
  useEffect(() => {
    if (!playerId) return;
    let stopped = false;
    const poll = async () => {
      try {
        const res = await fetch(`/api/rooms/${code}/state?playerId=${playerId}`, {
          cache: "no-store",
        });
        if (res.status === 404) {
          setError("Комната не найдена");
          return;
        }
        const data = await res.json();
        if (!stopped && data.state) setState(data.state);
      } catch {
        /* network hiccup */
      }
    };
    void poll();
    const iv = setInterval(poll, 1500);
    return () => {
      stopped = true;
      clearInterval(iv);
    };
  }, [playerId, code]);

  // sound effects driven by state changes
  useEffect(() => {
    if (!state) return;
    if (state.lastHit && state.lastHit.t !== sfxRef.current.hit) {
      sfxRef.current.hit = state.lastHit.t;
      if (state.lastHit.kind === "button") sfx.bell();
      else sfx.bang();
    }
    if (state.objection && state.objection.t !== sfxRef.current.obj) {
      sfxRef.current.obj = state.objection.t;
      sfx.objection();
    }
    if (state.verdict && state.verdict !== sfxRef.current.verdict) {
      sfxRef.current.verdict = state.verdict;
      sfx.verdict();
    }
  }, [state]);

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 2800);
  }, []);

  const action = useCallback(
    async (body: Record<string, unknown>, silent = false) => {
      if (!playerId) return;
      try {
        const res = await fetch(`/api/rooms/${code}/action`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ playerId, ...body }),
        });
        const data = await res.json();
        if (!res.ok) {
          if (!silent) showToast(data.error || "Ошибка");
        } else if (data.state) setState(data.state);
      } catch {
        showToast("Ошибка сети");
      }
    },
    [playerId, code, showToast]
  );

  const loadCases = useCallback(async () => {
    setShowCases(true);
    if (cases) return;
    try {
      const res = await fetch("/api/cases", { cache: "no-store" });
      const data = await res.json();
      setCases(data.cases || []);
    } catch {
      setCases([]);
    }
  }, [cases]);

  const me = state?.players.find((p) => p.id === playerId) ?? null;
  const myHand = (playerId && state?.hands[playerId]) || [];
  const isJudge = me?.role === "judge";

  const peerIds = useMemo(
    () => (state ? state.players.filter((p) => p.id !== playerId).map((p) => p.id) : []),
    [state, playerId]
  );
  const judgeMutedIds = useMemo(
    () => (state ? state.players.filter((p) => p.muted).map((p) => p.id) : []),
    [state]
  );

  const { status: voiceStatus, connectedIds } = useVoiceChat({
    code,
    playerId,
    peerIds,
    enabled: voiceEnabled,
    micOn,
    judgeMutedMe: !!me?.muted,
    judgeMutedIds,
    masterVolume,
  });

  /* ---------- join screen for direct links ---------- */
  if (joining && !playerId) {
    return (
      <JoinScreen
        code={code}
        onJoined={(id) => {
          setPlayerId(id);
          setJoining(false);
        }}
        onBack={() => router.push("/")}
      />
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-[#120a1c] text-amber-50 flex items-center justify-center">
        <div className="text-center">
          <div className="text-5xl mb-3">🚪</div>
          <p>{error}</p>
          <button
            onClick={() => router.push("/")}
            className="mt-4 px-5 py-2 rounded-xl bg-amber-500 text-black font-bold"
          >
            На главную
          </button>
        </div>
      </div>
    );
  }

  if (!state || !me) {
    return (
      <div className="min-h-screen bg-[#120a1c] text-amber-200 flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl animate-bounce">⚖️</div>
          <p className="mt-4">Входим в зал…</p>
        </div>
      </div>
    );
  }

  const speaker = state.players.find((p) => p.id === state.speakerId) ?? null;
  const speechLeft = state.speakerSince
    ? Math.max(0, SPEECH_LIMIT_MS - (now - state.speakerSince))
    : 0;
  const speechPct = Math.round((speechLeft / SPEECH_LIMIT_MS) * 100);

  return (
    <div className="h-screen w-screen relative overflow-hidden bg-[#171022] text-amber-50 select-none">
      {/* 3D */}
      <div className="absolute inset-0">
        <CourtScene
          state={state}
          myId={playerId!}
          firstPerson={firstPerson}
          onHammer={(targetId) => action({ type: "hammerPlayer", targetId })}
          onButton={() => action({ type: "giveFloor" })}
        />
      </div>

      {/* ============ top bar ============ */}
      <div className="absolute top-0 inset-x-0 p-3 flex items-start gap-3 pointer-events-none">
        <div className="pointer-events-auto rounded-2xl bg-black/65 backdrop-blur-md border border-white/10 px-4 py-2 shadow-xl">
          <div className="text-xs text-white/50">
            Комната{" "}
            <button
              className="font-mono font-bold text-amber-300 hover:underline"
              onClick={() => {
                navigator.clipboard?.writeText(code).catch(() => {});
                showToast("Код скопирован — отправьте его друзьям");
              }}
              title="Скопировать код"
            >
              {code}
            </button>{" "}
            · дело №{state.round}
          </div>
          <div className="text-sm flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full" style={{ background: ROLE_COLORS[me.role ?? "witness"] }} />
            <span className="font-semibold">{me.name}</span>
            <span className="text-xs text-white/45">{me.role ? ROLE_LABELS[me.role] : "без роли"}</span>
          </div>
        </div>

        <div className="pointer-events-auto flex-1 max-w-xl mx-auto rounded-2xl bg-black/65 backdrop-blur-md border border-amber-500/25 px-5 py-2 text-center shadow-xl">
          <div className="text-[10px] uppercase tracking-[0.25em] text-amber-400/80">
            {state.phase === "lobby" ? "Лобби" : state.phase === "topic" ? "Формулировка дела" : state.phase === "verdict" ? "Вердикт" : "Заседание"}
          </div>
          <div className="text-sm font-semibold leading-snug">
            {state.topic || "Обвинение ещё не предъявлено"}
          </div>
          {state.phase === "trial" && (
            <div className="mt-1">
              {state.onBreak ? (
                <div className="text-xs text-amber-300">☕ Перерыв — судья объявил паузу</div>
              ) : speaker ? (
                <>
                  <div className="text-xs text-amber-300">
                    🎙️ Говорит: <b>{speaker.name}</b>
                  </div>
                  <div className="h-1.5 mt-1 rounded-full bg-white/10 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        speechPct > 40 ? "bg-emerald-400" : speechPct > 15 ? "bg-amber-400" : "bg-red-500"
                      }`}
                      style={{ width: `${speechPct}%` }}
                    />
                  </div>
                </>
              ) : (
                <div className="text-xs text-white/45">Слово никому не дано — судья нажмёт кнопку 🔔</div>
              )}
            </div>
          )}
        </div>

        <div className="pointer-events-auto ml-auto flex flex-col items-end gap-2">
          <div className="flex items-center gap-2 rounded-2xl bg-black/65 backdrop-blur-md border border-white/10 px-3 py-2 shadow-xl">
            <button
              onClick={() => {
                setVoiceEnabled((v) => !v);
                if (!voiceEnabled) {
                  sfx.pop();
                  showToast("Голос включён — говорите свободно");
                }
              }}
              className={`rounded-xl px-3 py-2 text-sm font-bold border transition ${
                voiceEnabled
                  ? "bg-emerald-500/25 border-emerald-400/60 text-emerald-200"
                  : "bg-amber-500/25 border-amber-400/60 text-amber-200 animate-pulse"
              }`}
            >
              {voiceEnabled ? `🎙️ Голос вкл · ${connectedIds.length}/${peerIds.length}` : "🔇 Включить голос"}
            </button>
            {voiceEnabled && (
              <>
                <button
                  onClick={() => setMicOn((v) => !v)}
                  title={micOn ? "Выключить свой микрофон" : "Включить свой микрофон"}
                  className={`w-9 h-9 rounded-xl border text-lg ${
                    micOn && !me.muted
                      ? "border-emerald-400/50 bg-emerald-500/15"
                      : "border-red-400/50 bg-red-500/15"
                  }`}
                >
                  {me.muted ? "🔇" : micOn ? "🎤" : "🎤"}
                </button>
                <div className="flex flex-col items-center w-24">
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={masterVolume}
                    onChange={(e) => setMasterVolume(Number(e.target.value))}
                    className="w-full accent-amber-400"
                    title="Громкость собеседников"
                  />
                  <span className="text-[9px] text-white/40">громкость {masterVolume}%</span>
                </div>
              </>
            )}
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => setFirstPerson((v) => !v)}
              className={`rounded-xl px-3 py-2 text-xs font-bold border backdrop-blur transition ${
                firstPerson
                  ? "bg-indigo-500/30 border-indigo-400/60 text-indigo-100"
                  : "bg-black/60 border-white/10 text-white/70 hover:bg-white/10"
              }`}
            >
              {firstPerson ? "👁️ От первого лица" : "🎥 Обзор зала"}
            </button>
            <button
              onClick={() => setShowHelp(true)}
              className="rounded-xl px-3 py-2 text-xs font-bold border bg-black/60 border-white/10 text-white/70 hover:bg-white/10"
            >
              ❓ Как играть
            </button>
            <button
              onClick={loadCases}
              className="rounded-xl px-3 py-2 text-xs font-bold border bg-black/60 border-white/10 text-white/70 hover:bg-white/10"
            >
              📜 Архив дел
            </button>
          </div>
        </div>
      </div>

      {/* ============ players panel ============ */}
      <div className="absolute left-3 top-32 w-64 rounded-2xl bg-black/65 backdrop-blur-md border border-white/10 p-3 space-y-1 max-h-[46vh] overflow-y-auto shadow-xl">
        <div className="text-[10px] uppercase tracking-[0.2em] text-white/40 mb-1">
          Участники ({state.players.length})
        </div>
        {state.players.map((p) => (
          <div key={p.id} className="flex items-center gap-2 text-sm">
            <span className="w-2 h-2 rounded-full shrink-0" style={{ background: ROLE_COLORS[p.role ?? "witness"] }} />
            <span className={`truncate ${p.id === playerId ? "font-bold text-amber-200" : ""}`}>
              {p.name}
              {state.speakerId === p.id ? " 🎙️" : ""}
              {p.muted ? " 🔇" : ""}
              {state.handsUp.includes(p.id) ? " ✋" : ""}
            </span>
            <span className="ml-auto text-[10px] text-white/40 shrink-0">
              {p.role ? ROLE_LABELS[p.role] : "—"}
            </span>
            {isJudge && p.id !== playerId && state.phase === "trial" && (
              <span className="flex gap-1 shrink-0">
                <button
                  title={p.muted ? "Вернуть голос (молоток)" : "Заглушить молотком"}
                  onClick={() => action({ type: "hammerPlayer", targetId: p.id })}
                  className="text-sm hover:scale-125 transition"
                >
                  🔨
                </button>
                <button
                  title="Дать слово"
                  onClick={() => action({ type: "giveFloor", targetId: p.id })}
                  className="text-sm hover:scale-125 transition"
                >
                  🔔
                </button>
              </span>
            )}
          </div>
        ))}

        {isJudge && state.phase === "trial" && (
          <div className="pt-2 mt-2 border-t border-white/10 grid grid-cols-2 gap-2">
            <button
              onClick={() => action({ type: "giveFloor" })}
              className="rounded-lg bg-amber-500/80 hover:bg-amber-400 text-black text-xs font-bold py-2"
            >
              🔔 Дать слово
            </button>
            <button
              onClick={() => action({ type: "endSpeech" })}
              className="rounded-lg bg-white/10 hover:bg-white/20 text-xs font-bold py-2"
            >
              ✋ Забрать слово
            </button>
            <button
              onClick={() => action({ type: "break" })}
              className="rounded-lg bg-amber-900/60 hover:bg-amber-800/70 text-xs font-bold py-2"
            >
              ☕ {state.onBreak ? "Продолжить" : "Перерыв"}
            </button>
            <button
              onClick={() => action({ type: "verdict", verdict: "innocent" })}
              className="rounded-lg bg-emerald-600/80 hover:bg-emerald-500 text-xs font-bold py-2"
            >
              🕊️ Невиновен
            </button>
            <button
              onClick={() => action({ type: "verdict", verdict: "guilty" })}
              className="rounded-lg bg-red-600/80 hover:bg-red-500 text-xs font-bold py-2 col-span-2"
            >
              ⛓️ Виновен
            </button>
          </div>
        )}
      </div>

      {/* ============ log & chat ============ */}
      <div className="absolute right-3 top-32 w-80 rounded-2xl bg-black/65 backdrop-blur-md border border-white/10 p-3 shadow-xl flex flex-col max-h-[52vh]">
        <div className="text-[10px] uppercase tracking-[0.2em] text-white/40 mb-2">Хроника заседания</div>
        <div className="flex-1 overflow-y-auto flex flex-col-reverse space-y-1 space-y-reverse">
          {state.log.slice(-30).map((l, i) => (
            <div
              key={i}
              className={`text-xs leading-snug rounded-lg px-2 py-1 ${
                l.kind === "chat"
                  ? "bg-white/5 text-white/85"
                  : l.kind === "hammer"
                  ? "bg-red-500/10 text-red-200"
                  : l.kind === "card"
                  ? "bg-indigo-500/10 text-indigo-200"
                  : l.kind === "verdict"
                  ? "bg-amber-500/15 text-amber-200 font-semibold"
                  : l.kind === "fun"
                  ? "bg-emerald-500/10 text-emerald-200"
                  : "text-white/60"
              }`}
            >
              {l.kind === "chat" && <b className="text-amber-300">{l.who}: </b>}
              {l.text}
            </div>
          ))}
        </div>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (!chatDraft.trim()) return;
            void action({ type: "chat", text: chatDraft }, true);
            setChatDraft("");
          }}
          className="mt-2 flex gap-2"
        >
          <input
            value={chatDraft}
            onChange={(e) => setChatDraft(e.target.value)}
            maxLength={160}
            placeholder="Сообщение в зал…"
            className="flex-1 rounded-xl bg-black/40 border border-white/15 px-3 py-2 text-xs outline-none focus:border-amber-400"
          />
          <button className="rounded-xl bg-amber-500/80 text-black text-xs font-bold px-3 hover:bg-amber-400">
            ➤
          </button>
        </form>
      </div>

      {/* ============ cards ============ */}
      {state.phase === "trial" && myHand.length > 0 && (
        <div className="absolute bottom-3 inset-x-0 flex justify-center gap-3 px-3 pointer-events-none flex-wrap">
          {myHand.map((card) => (
            <button
              key={card.id}
              disabled={card.used}
              onClick={() => {
                sfx.flip();
                void action({ type: "playCard", cardId: card.id });
              }}
              className={`pointer-events-auto w-40 rounded-2xl border p-3 text-left transition transform hover:-translate-y-2 shadow-2xl ${
                card.used
                  ? "bg-black/50 border-white/10 opacity-35 cursor-not-allowed"
                  : me.role === "prosecutor"
                  ? "bg-gradient-to-b from-red-950/95 to-red-900/80 border-red-500/60 hover:border-red-400"
                  : "bg-gradient-to-b from-indigo-950/95 to-indigo-900/80 border-blue-500/60 hover:border-blue-400"
              } backdrop-blur-md`}
            >
              <div className="text-[13px] font-bold">
                🃏 {card.title} {card.used && "✓"}
              </div>
              <div className="text-[10px] text-white/65 mt-1 leading-snug">{card.text}</div>
            </button>
          ))}
        </div>
      )}

      {/* ============ action bar ============ */}
      <div className="absolute bottom-3 left-3 flex flex-col gap-2 pointer-events-auto">
        <div className="flex gap-2 flex-wrap max-w-[420px]">
          {REACTIONS.map((emoji) => (
            <button
              key={emoji}
              onClick={() => {
                sfx.pop();
                void action({ type: "reaction", emoji }, true);
              }}
              className="w-10 h-10 rounded-xl bg-black/60 backdrop-blur border border-white/10 text-lg hover:bg-white/15 hover:scale-110 transition"
            >
              {emoji}
            </button>
          ))}
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => void action({ type: "raiseHand" }, true)}
            className={`rounded-xl px-4 py-2 text-sm font-bold border ${
              state.handsUp.includes(playerId!)
                ? "bg-amber-400/30 border-amber-300 text-amber-100"
                : "bg-black/60 border-white/10 text-white/75 hover:bg-white/10"
            }`}
          >
            ✋ Просить слово
          </button>
          <button
            onClick={() => {
              sfx.objection();
              void action({ type: "objection" });
            }}
            className="rounded-xl px-4 py-2 text-sm font-bold border bg-red-600/80 border-red-400/60 hover:bg-red-500 text-white shadow-lg hover:scale-105 transition"
          >
            🚨 ПРОТЕСТ!
          </button>
        </div>
      </div>

      {/* ============ lobby ============ */}
      {state.phase === "lobby" && (
        <div className="absolute inset-x-0 bottom-0 p-4 flex justify-center">
          <div className="rounded-3xl bg-black/80 backdrop-blur-xl border border-white/10 p-6 w-full max-w-3xl shadow-2xl">
            <div className="text-center mb-4">
              <div className="font-black text-2xl">Выберите роль</div>
              <div className="text-xs text-white/55 mt-1">
                Код зала:{" "}
                <button
                  className="font-mono text-amber-300 font-bold hover:underline"
                  onClick={() => {
                    navigator.clipboard?.writeText(code).catch(() => {});
                    showToast("Код скопирован");
                  }}
                >
                  {code}
                </button>{" "}
                — отправьте ссылку или код друзьям. Минимум 3 игрока.
              </div>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {(["judge", "prosecutor", "advocate", "witness"] as Role[]).map((r) => {
                const takenBy = state.players.find((p) => p.role === r && r !== "witness");
                const mine = me.role === r;
                const disabled = !!takenBy && !mine && r !== "witness";
                return (
                  <button
                    key={r}
                    disabled={disabled}
                    onClick={() => {
                      sfx.pop();
                      void action({ type: "chooseRole", role: r });
                    }}
                    className={`rounded-2xl border p-4 text-center transition ${
                      mine
                        ? "border-amber-400 bg-amber-400/15 scale-[1.03]"
                        : disabled
                        ? "border-white/10 bg-white/5 opacity-40 cursor-not-allowed"
                        : "border-white/15 bg-white/5 hover:bg-white/10 hover:scale-[1.03]"
                    }`}
                  >
                    <div className="text-3xl mb-1">
                      {r === "judge" ? "🧑‍⚖️" : r === "prosecutor" ? "🔥" : r === "advocate" ? "🛡️" : "👀"}
                    </div>
                    <div className="text-sm font-bold" style={{ color: ROLE_COLORS[r] }}>
                      {ROLE_LABELS[r]}
                    </div>
                    <div className="text-[10px] text-white/45 mt-1">
                      {r === "witness"
                        ? "сколько угодно"
                        : takenBy
                        ? `занято: ${takenBy.name}`
                        : "свободно"}
                    </div>
                  </button>
                );
              })}
            </div>
            <button
              onClick={() => {
                sfx.bell();
                void action({ type: "start" });
              }}
              className="mt-5 w-full rounded-2xl bg-gradient-to-r from-amber-400 to-orange-500 text-black font-black py-4 text-lg hover:brightness-110 shadow-xl"
            >
              ⚖️ Начать заседание
            </button>
          </div>
        </div>
      )}

      {/* ============ topic ============ */}
      {state.phase === "topic" && (
        <div className="absolute inset-0 bg-black/65 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="rounded-3xl bg-[#221436] border border-white/10 p-8 w-full max-w-xl text-center shadow-2xl">
            {me.role === "prosecutor" ? (
              <>
                <div className="text-5xl mb-2">🔥</div>
                <div className="font-black text-2xl mb-2">Вы — прокурор!</div>
                <p className="text-sm text-white/65 mb-5">
                  Сформулируйте обвинение. Например: «Обвиняемый съел чужой обед из офисного
                  холодильника» или «Продавал котиков под видом щенков».
                </p>
                <input
                  value={topicDraft}
                  onChange={(e) => setTopicDraft(e.target.value)}
                  maxLength={120}
                  placeholder="В чём обвиняем?"
                  className="w-full rounded-2xl bg-black/45 border border-white/15 px-5 py-4 outline-none focus:border-amber-400 text-lg"
                />
                <button
                  disabled={!topicDraft.trim()}
                  onClick={() => {
                    sfx.whoosh();
                    void action({ type: "setTopic", topic: topicDraft });
                  }}
                  className="mt-4 w-full rounded-2xl bg-gradient-to-r from-red-500 to-orange-500 font-black py-4 text-lg disabled:opacity-40 hover:brightness-110"
                >
                  📋 Предъявить обвинение
                </button>
              </>
            ) : (
              <>
                <div className="text-5xl mb-3 animate-pulse">📜</div>
                <div className="font-black text-2xl">Прокурор готовит обвинение…</div>
                <p className="text-sm text-white/60 mt-3">
                  Скоро раздадут карточки улик и алиби, и начнётся словесная битва. Разомните
                  связки и включите голос!
                </p>
              </>
            )}
          </div>
        </div>
      )}

      {/* ============ verdict ============ */}
      {state.phase === "verdict" && (
        <div className="absolute inset-0 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="rounded-3xl bg-[#221436] border border-white/10 p-10 text-center max-w-lg w-full shadow-2xl">
            <div className="text-7xl mb-4">{state.verdict === "guilty" ? "⛓️" : "🕊️"}</div>
            <div
              className={`text-4xl font-black ${
                state.verdict === "guilty" ? "text-red-400" : "text-emerald-400"
              }`}
            >
              {state.verdict === "guilty" ? "ВИНОВЕН!" : "НЕВИНОВЕН!"}
            </div>
            <p className="text-sm text-white/65 mt-3">
              Дело №{state.round} «{state.topic}» закрыто.{" "}
              {state.verdict === "guilty" ? "Победа прокурора!" : "Победа адвоката!"} Дело ушло в
              архив.
            </p>
            {isJudge ? (
              <button
                onClick={() => {
                  sfx.whoosh();
                  void action({ type: "restart" });
                }}
                className="mt-6 w-full rounded-2xl bg-gradient-to-r from-amber-400 to-orange-500 text-black font-black py-4 text-lg hover:brightness-110"
              >
                🔁 Новое дело
              </button>
            ) : (
              <div className="mt-6 text-xs text-white/45">Судья объявит новое дело…</div>
            )}
          </div>
        </div>
      )}

      {/* ============ objection flash ============ */}
      {state.objection && now - state.objection.t < 2200 && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div
            className="rounded-3xl bg-red-600/85 px-12 py-8 shadow-2xl border-4 border-red-300"
            style={{ transform: `rotate(-4deg) scale(${1 + Math.max(0, 1 - (now - state.objection.t) / 1200) * 0.06})` }}
          >
            <div className="text-6xl font-black tracking-wider drop-shadow-lg">🚨 ПРОТЕСТ!</div>
            <div className="text-center text-red-100 mt-1">
              {state.players.find((p) => p.id === state.objection!.playerId)?.name} возражает!
            </div>
          </div>
        </div>
      )}

      {/* ============ hint ============ */}
      {isJudge && state.phase === "trial" && (
        <div className="absolute bottom-3 right-3 rounded-2xl bg-black/65 backdrop-blur-md border border-white/10 px-4 py-3 text-xs text-white/65 max-w-[280px]">
          🔨 Клик по игроку в 3D — удар молотком (мут / возврат голоса).
          <br />🔔 Клик по красной кнопке на столе судьи — передать слово.
          <br />👁️ Вид от первого лица: тяните мышью для обзора, W A S D — ходьба.
        </div>
      )}
      {firstPerson && (
        <div className="absolute bottom-3 right-3 rounded-2xl bg-black/55 border border-white/10 px-3 py-2 text-[11px] text-white/60">
          🖱️ Тяните мышью — обзор · W A S D / стрелки — ходьба · Shift — бег
        </div>
      )}

      {/* ============ help modal ============ */}
      {showHelp && (
        <Modal onClose={() => setShowHelp(false)} title="Как играть с друзьями">
          <ol className="space-y-3 text-sm text-white/80 list-decimal list-inside">
            <li>
              <b>Поделитесь ссылкой</b> на эту страницу или кодом зала{" "}
              <b className="font-mono text-amber-300">{code}</b> — друзья заходят с любого
              устройства (ПК или телефон).
            </li>
            <li>
              Каждый входит по коду, выбирает роль: <b style={{ color: ROLE_COLORS.judge }}>судья</b>,{" "}
              <b style={{ color: ROLE_COLORS.prosecutor }}>прокурор</b>,{" "}
              <b style={{ color: ROLE_COLORS.advocate }}>адвокат</b> и любое число свидетелей.
            </li>
            <li>
              Нажмите <b className="text-amber-300">«Включить голос»</b> в правом верхнем углу —
              браузер спросит разрешение на микрофон. Без этого голос не работает!
            </li>
            <li>Прокурор пишет тему дела, всем сторонам раздаются карточки улик и алиби.</li>
            <li>
              Судья кликает по игрокам молотком 🔨 (мут) и бьёт по красной кнопке 🔔, чтобы дать
              слово. Выкладывайте карточки, спорьте, кидайте реакции и нажимайте «ПРОТЕСТ!».
            </li>
            <li>Судья выносит вердикт — дело уходит в архив.</li>
          </ol>
          <div className="mt-4 rounded-xl bg-amber-500/10 border border-amber-400/30 p-3 text-xs text-amber-100">
            💡 Голос работает напрямую между устройствами (WebRTC). Если за NAT-файрволлом
            собеседника не слышно — включите «Включить голос» заново и попросите его сделать то же.
          </div>
        </Modal>
      )}

      {/* ============ cases modal ============ */}
      {showCases && (
        <Modal onClose={() => setShowCases(false)} title="📜 Архив дел">
          {!cases ? (
            <div className="text-white/60 text-sm">Загружаем…</div>
          ) : cases.length === 0 ? (
            <div className="text-white/60 text-sm">Пока ни одного закрытого дела. Самое время!</div>
          ) : (
            <div className="space-y-2 max-h-[50vh] overflow-y-auto">
              {cases.map((c) => (
                <div key={c.id} className="rounded-xl border border-white/10 bg-white/5 p-3">
                  <div className="flex items-start gap-2">
                    <div className="text-xl">{c.verdict === "guilty" ? "⛓️" : "🕊️"}</div>
                    <div className="flex-1">
                      <div className="text-sm font-semibold">{c.topic}</div>
                      <div className="text-[11px] text-white/50">
                        зал {c.roomCode} ·{" "}
                        {new Date(c.createdAt).toLocaleString("ru-RU", {
                          day: "2-digit",
                          month: "short",
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </div>
                      <div className="text-[11px] text-white/60 mt-1">
                        {(c.players || [])
                          .map((p) => `${p.name} — ${p.role ? ROLE_LABELS[p.role as Role] : "—"}`)
                          .join(" · ")}
                      </div>
                    </div>
                    <div
                      className={`text-xs font-bold px-2 py-1 rounded-lg ${
                        c.verdict === "guilty"
                          ? "bg-red-500/20 text-red-200"
                          : "bg-emerald-500/20 text-emerald-200"
                      }`}
                    >
                      {c.verdict === "guilty" ? "ВИНОВЕН" : "НЕВИНОВЕН"}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Modal>
      )}

      {/* toast */}
      {toast && (
        <div className="absolute top-24 left-1/2 -translate-x-1/2 rounded-2xl bg-amber-400 text-black font-bold px-5 py-2.5 shadow-2xl z-50">
          {toast}
        </div>
      )}
    </div>
  );
}

/* ---------- modal ---------- */
function Modal({
  title,
  children,
  onClose,
}: {
  title: string;
  children: React.ReactNode;
  onClose: () => void;
}) {
  return (
    <div className="absolute inset-0 z-40 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="rounded-3xl bg-[#221436] border border-white/10 p-6 w-full max-w-xl shadow-2xl">
        <div className="flex items-center justify-between mb-4">
          <div className="font-black text-xl">{title}</div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-white/10 hover:bg-white/20 text-lg"
          >
            ✕
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

/* ---------- join screen for people opening a direct link ---------- */
function JoinScreen({
  code,
  onJoined,
  onBack,
}: {
  code: string;
  onJoined: (playerId: string) => void;
  onBack: () => void;
}) {
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    const saved = sessionStorage.getItem("court-name");
    if (saved) setName(saved);
  }, []);

  async function join() {
    setBusy(true);
    setErr(null);
    try {
      const res = await fetch(`/api/rooms/${code}/join`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Ошибка");
      sessionStorage.setItem(`court-player-${code}`, data.playerId);
      sessionStorage.setItem("court-name", name);
      onJoined(data.playerId);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Ошибка");
      setBusy(false);
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1a1026] to-[#120a1c] text-amber-50 flex items-center justify-center p-6">
      <div className="rounded-3xl bg-white/5 border border-white/10 p-8 w-full max-w-sm text-center shadow-2xl">
        <div className="text-6xl mb-2">⚖️</div>
        <div className="font-black text-xl">
          Вход в зал <span className="font-mono text-amber-300">{code}</span>
        </div>
        <div className="text-xs text-white/50 mt-1">Вас пригласили на судебное заседание</div>
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          maxLength={20}
          placeholder="Ваше имя"
          className="mt-5 w-full rounded-2xl bg-black/30 border border-white/15 px-4 py-4 outline-none focus:border-amber-400 text-lg"
        />
        <button
          disabled={!name.trim() || busy}
          onClick={join}
          className="mt-4 w-full rounded-2xl bg-gradient-to-r from-amber-400 to-orange-500 text-black font-black py-4 text-lg disabled:opacity-40"
        >
          Войти в зал
        </button>
        {err && <div className="mt-3 text-sm text-red-300">{err}</div>}
        <button onClick={onBack} className="mt-4 text-xs text-white/40 hover:text-white/70">
          ← на главную
        </button>
      </div>
    </div>
  );
}
