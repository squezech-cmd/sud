"use client";

import { Suspense, useEffect, useMemo, useRef, useState } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Html, OrbitControls, useTexture } from "@react-three/drei";
import * as THREE from "three";
import type { Player, RoomState } from "@/lib/game";
import { ROLE_COLORS, ROLE_LABELS } from "@/lib/game";

type Vec3 = [number, number, number];

type Props = {
  state: RoomState;
  myId: string;
  firstPerson: boolean;
  onHammer: (targetId: string) => void;
  onButton: () => void;
};

const JUDGE_POS: Vec3 = [0, 1.7, -5.05];
const PROSECUTOR_POS: Vec3 = [-4, 0, -0.6];
const ADVOCATE_POS: Vec3 = [4, 0, -0.6];
const BUTTON_POS: Vec3 = [1.5, 1.74, -4.3];
const GAVEL_REST: Vec3 = [-1.25, 2.06, -4.4];

function witnessPos(i: number): Vec3 {
  const row = Math.floor(i / 4);
  const col = i % 4;
  return [-3.6 + col * 2.4, 0, 2.7 + row * 1.7];
}

export function playerPositions(players: Player[]): Map<string, Vec3> {
  const map = new Map<string, Vec3>();
  let w = 0;
  for (const p of players) {
    if (p.role === "judge") map.set(p.id, JUDGE_POS);
    else if (p.role === "prosecutor") map.set(p.id, PROSECUTOR_POS);
    else if (p.role === "advocate") map.set(p.id, ADVOCATE_POS);
    else map.set(p.id, witnessPos(w++));
  }
  return map;
}

/* ================= First person controls ================= */
function FirstPerson({
  enabled,
  spawn,
}: {
  enabled: boolean;
  spawn: Vec3;
}) {
  const { camera, gl } = useThree();
  const yaw = useRef(0);
  const pitch = useRef(0);
  const keys = useRef<Record<string, boolean>>({});
  const dragging = useRef(false);
  const moving = useRef(false);
  const spawnRef = useRef<Vec3>(spawn);
  spawnRef.current = spawn;

  useEffect(() => {
    if (!enabled) return;
    const s = spawnRef.current;
    camera.rotation.order = "YXZ";
    camera.position.set(s[0], 1.72, s[2] + 1.2);
    camera.lookAt(0, 1.6, -2);
    yaw.current = camera.rotation.y;
    pitch.current = camera.rotation.x;

    const el = gl.domElement;
    const onDown = (e: PointerEvent) => {
      dragging.current = true;
      el.setPointerCapture?.(e.pointerId);
    };
    const onUp = (e: PointerEvent) => {
      dragging.current = false;
      el.releasePointerCapture?.(e.pointerId);
    };
    const onMove = (e: PointerEvent) => {
      if (!dragging.current) return;
      yaw.current -= e.movementX * 0.0028;
      pitch.current = Math.max(-1.15, Math.min(1.15, pitch.current - e.movementY * 0.0028));
    };
    const onKeyDown = (e: KeyboardEvent) => {
      keys.current[e.code] = true;
    };
    const onKeyUp = (e: KeyboardEvent) => {
      keys.current[e.code] = false;
    };

    el.addEventListener("pointerdown", onDown);
    el.addEventListener("pointerup", onUp);
    el.addEventListener("pointermove", onMove);
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    return () => {
      el.removeEventListener("pointerdown", onDown);
      el.removeEventListener("pointerup", onUp);
      el.removeEventListener("pointermove", onMove);
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      camera.rotation.set(0, 0, 0);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enabled]);

  useFrame((_, delta) => {
    if (!enabled) return;
    camera.rotation.set(pitch.current, yaw.current, 0);

    const k = keys.current;
    const forward = (k["KeyW"] || k["ArrowUp"] ? 1 : 0) - (k["KeyS"] || k["ArrowDown"] ? 1 : 0);
    const strafe = (k["KeyD"] || k["ArrowRight"] ? 1 : 0) - (k["KeyA"] || k["ArrowLeft"] ? 1 : 0);
    moving.current = forward !== 0 || strafe !== 0;

    const speed = k["ShiftLeft"] || k["ShiftRight"] ? 6.5 : 3.6;
    const dir = new THREE.Vector3();
    camera.getWorldDirection(dir);
    dir.y = 0;
    dir.normalize();
    const right = new THREE.Vector3().crossVectors(dir, new THREE.Vector3(0, 1, 0));

    camera.position.addScaledVector(dir, forward * speed * delta);
    camera.position.addScaledVector(right, strafe * speed * delta);
    camera.position.x = Math.max(-9.5, Math.min(9.5, camera.position.x));
    camera.position.z = Math.max(-6.2, Math.min(7.2, camera.position.z));

    const bob = moving.current ? Math.sin(performance.now() / 130) * 0.035 : 0;
    camera.position.y = 1.72 + bob;
  });

  return null;
}

/* ================= Materials & textures ================= */
function Textures() {
  return null;
}

function useCourtTextures() {
  const [floor, wall, velvet] = useTexture([
    "/textures/wood-floor.jpg",
    "/textures/wood-wall.jpg",
    "/textures/velvet.jpg",
  ]);
  useEffect(() => {
    for (const t of [floor, wall, velvet]) {
      t.wrapS = t.wrapT = THREE.RepeatWrapping;
      t.colorSpace = THREE.SRGBColorSpace;
      t.anisotropy = 8;
    }
    floor.repeat.set(6, 5);
    wall.repeat.set(5, 2.2);
    velvet.repeat.set(1.6, 1);
  }, [floor, wall, velvet]);
  return { floor, wall, velvet };
}

/* ================= Detailed courtroom ================= */
function Courtroom() {
  const { floor, wall, velvet } = useCourtTextures();
  const gold = useMemo(
    () => new THREE.MeshStandardMaterial({ color: "#c9a227", metalness: 0.85, roughness: 0.35 }),
    []
  );
  const darkWood = useMemo(
    () => new THREE.MeshStandardMaterial({ map: wall, color: "#7a5230", roughness: 0.72 }),
    [wall]
  );
  const bookColors = ["#7f1d1d", "#1e3a5f", "#14532d", "#7c2d12", "#3b0764", "#713f12"];

  return (
    <group>
      {/* floor + carpet */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[22, 18]} />
        <meshStandardMaterial map={floor} color="#b08458" roughness={0.55} metalness={0.05} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.012, -1]}>
        <planeGeometry args={[3.2, 10.5]} />
        <meshStandardMaterial color="#8b1c2b" roughness={0.95} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.014, -4.2]}>
        <planeGeometry args={[11, 2.6]} />
        <meshStandardMaterial color="#7c1724" roughness={0.95} />
      </mesh>

      {/* walls */}
      <mesh position={[0, 3.6, -7.5]} receiveShadow>
        <boxGeometry args={[22, 7.2, 0.35]} />
        <primitive object={darkWood} attach="material" />
      </mesh>
      <mesh position={[-11, 3.6, 0]} receiveShadow>
        <boxGeometry args={[0.35, 7.2, 18]} />
        <primitive object={darkWood} attach="material" />
      </mesh>
      <mesh position={[11, 3.6, 0]} receiveShadow>
        <boxGeometry args={[0.35, 7.2, 18]} />
        <primitive object={darkWood} attach="material" />
      </mesh>
      {/* ceiling */}
      <mesh rotation={[Math.PI / 2, 0, 0]} position={[0, 7.2, 0]}>
        <planeGeometry args={[22, 18]} />
        <meshStandardMaterial color="#2b1d14" roughness={1} />
      </mesh>

      {/* columns */}
      {[-9.6, -3.2, 3.2, 9.6].map((x) => (
        <group key={x} position={[x, 0, -7.1]}>
          <mesh position={[0, 3.5, 0]} castShadow>
            <cylinderGeometry args={[0.42, 0.5, 7, 18]} />
            <meshStandardMaterial color="#c9b08a" roughness={0.6} />
          </mesh>
          <mesh position={[0, 0.25, 0]}>
            <cylinderGeometry args={[0.68, 0.72, 0.5, 18]} />
            <meshStandardMaterial color="#b89b73" roughness={0.6} />
          </mesh>
          <mesh position={[0, 6.85, 0]}>
            <boxGeometry args={[1.2, 0.42, 1.2]} />
            <meshStandardMaterial color="#b89b73" roughness={0.6} />
          </mesh>
          <mesh position={[0, 6.55, 0]}>
            <cylinderGeometry args={[0.62, 0.5, 0.28, 18]} />
            <primitive object={gold} attach="material" />
          </mesh>
        </group>
      ))}

      {/* back-wall panel + emblem */}
      <mesh position={[0, 3.4, -7.28]}>
        <boxGeometry args={[6.4, 4.4, 0.12]} />
        <meshStandardMaterial color="#5c2b26" roughness={0.9} />
      </mesh>
      <mesh position={[0, 3.4, -7.18]}>
        <torusGeometry args={[1.25, 0.09, 12, 48]} />
        <primitive object={gold} attach="material" />
      </mesh>
      <Html position={[0, 3.4, -7.15]} center distanceFactor={12}>
        <div style={{ fontSize: 92, pointerEvents: "none", filter: "drop-shadow(0 6px 12px rgba(0,0,0,0.6))" }}>⚖️</div>
      </Html>

      {/* velvet curtains */}
      {[-4.6, 4.6].map((x) => (
        <group key={x} position={[x, 4.1, -7.1]}>
          <mesh castShadow>
            <boxGeometry args={[1.9, 5.6, 0.22]} />
            <meshStandardMaterial map={velvet} color="#b0202c" roughness={1} />
          </mesh>
          <mesh position={[0, -2.6, 0.16]}>
            <boxGeometry args={[2.1, 0.36, 0.36]} />
            <primitive object={gold} attach="material" />
          </mesh>
        </group>
      ))}

      {/* chandelier */}
      <group position={[0, 5.6, -1.2]}>
        <mesh position={[0, 1.1, 0]}>
          <cylinderGeometry args={[0.05, 0.05, 2.2, 8]} />
          <meshStandardMaterial color="#3b2a1c" metalness={0.7} roughness={0.5} />
        </mesh>
        <mesh rotation={[Math.PI / 2, 0, 0]} castShadow>
          <torusGeometry args={[1.15, 0.08, 12, 40]} />
          <primitive object={gold} attach="material" />
        </mesh>
        <mesh position={[0, -0.45, 0]} rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[0.6, 0.06, 12, 32]} />
          <primitive object={gold} attach="material" />
        </mesh>
        {[0, 1, 2, 3, 4, 5].map((i) => {
          const a = (i / 6) * Math.PI * 2;
          return (
            <group key={i} position={[Math.cos(a) * 1.15, 0.22, Math.sin(a) * 1.15]}>
              <mesh>
                <cylinderGeometry args={[0.055, 0.07, 0.42, 10]} />
                <meshStandardMaterial color="#f5e6c8" roughness={0.8} />
              </mesh>
              <mesh position={[0, 0.3, 0]}>
                <sphereGeometry args={[0.11, 12, 12]} />
                <meshBasicMaterial color="#ffd9a0" />
              </mesh>
            </group>
          );
        })}
        <pointLight position={[0, -0.2, 0]} intensity={26} distance={26} color="#ffcf96" castShadow />
      </group>

      {/* windows with warm light shafts on side walls */}
      {[-10.75, 10.75].map((x, side) =>
        [-3.6, 0.6, 4.8].map((z, i) => (
          <group key={`${side}-${i}`} position={[x, 3.9, z]} rotation={[0, side === 0 ? Math.PI / 2 : -Math.PI / 2, 0]}>
            <mesh>
              <planeGeometry args={[1.7, 2.9]} />
              <meshBasicMaterial color="#ffe2ad" toneMapped={false} />
            </mesh>
            <mesh position={[0, 0, -0.06]}>
              <boxGeometry args={[2.05, 3.25, 0.12]} />
              <meshStandardMaterial color="#4a3320" roughness={0.8} />
            </mesh>
            <mesh position={[0, 0, -0.02]}>
              <boxGeometry args={[0.1, 2.9, 0.1]} />
              <meshStandardMaterial color="#4a3320" />
            </mesh>
            <mesh position={[0, 0, -0.02]}>
              <boxGeometry args={[1.7, 0.1, 0.1]} />
              <meshStandardMaterial color="#4a3320" />
            </mesh>
          </group>
        ))
      )}

      {/* judge bench with platform, trim and props */}
      <group position={[0, 0, -4.55]}>
        <mesh position={[0, 0.32, -0.55]} receiveShadow>
          <boxGeometry args={[5.2, 0.64, 1.9]} />
          <meshStandardMaterial color="#4d3119" roughness={0.75} />
        </mesh>
        <mesh position={[0, 1.05, 0]} castShadow receiveShadow>
          <boxGeometry args={[4.8, 1.5, 1.15]} />
          <meshStandardMaterial map={wall} color="#8a5c33" roughness={0.65} />
        </mesh>
        <mesh position={[0, 1.83, 0]}>
          <boxGeometry args={[5.05, 0.14, 1.32]} />
          <meshStandardMaterial color="#6b4326" roughness={0.5} />
        </mesh>
        {/* carved trim */}
        {[-1.6, -0.8, 0, 0.8, 1.6].map((x) => (
          <mesh key={x} position={[x, 1.05, 0.6]}>
            <boxGeometry args={[0.07, 1.2, 0.04]} />
            <primitive object={gold} attach="material" />
          </mesh>
        ))}
        {/* nameplate */}
        <mesh position={[0, 2.06, 0.1]} rotation={[-0.35, 0, 0]}>
          <boxGeometry args={[1.5, 0.34, 0.05]} />
          <meshStandardMaterial color="#2c1a0f" roughness={0.5} />
        </mesh>
        <Html position={[0, 2.12, 0.32]} rotation={[-0.35, 0, 0]} center distanceFactor={9}>
          <div style={{ color: "#e8c987", fontSize: 15, letterSpacing: 3, fontFamily: "serif", pointerEvents: "none" }}>
            СУДЬЯ
          </div>
        </Html>
        {/* sound block for the gavel */}
        <mesh position={[GAVEL_REST[0], 1.92, GAVEL_REST[2]]} castShadow>
          <cylinderGeometry args={[0.32, 0.34, 0.12, 22]} />
          <meshStandardMaterial color="#4a2c15" roughness={0.6} />
        </mesh>
        {/* law books */}
        {[0, 1, 2].map((i) => (
          <mesh key={i} position={[-1.85, 1.96 + i * 0.11, 0.05]} rotation={[0, i * 0.12, 0]} castShadow>
            <boxGeometry args={[0.62, 0.1, 0.42]} />
            <meshStandardMaterial color={bookColors[i]} roughness={0.85} />
          </mesh>
        ))}
        {/* scales of justice */}
        <group position={[1.75, 2.02, 0]}>
          <mesh position={[0, 0.35, 0]}>
            <cylinderGeometry args={[0.035, 0.06, 0.7, 10]} />
            <primitive object={gold} attach="material" />
          </mesh>
          <mesh position={[0, 0.72, 0]} rotation={[0, 0, 0.25]}>
            <boxGeometry args={[1.15, 0.045, 0.045]} />
            <primitive object={gold} attach="material" />
          </mesh>
          {[-0.52, 0.52].map((x) => (
            <group key={x} position={[x, 0.62 - x * 0.25, 0]}>
              <mesh>
                <cylinderGeometry args={[0.17, 0.09, 0.1, 16]} />
                <primitive object={gold} attach="material" />
              </mesh>
              <mesh position={[0, 0.09, 0]}>
                <torusGeometry args={[0.17, 0.012, 8, 20]} />
                <primitive object={gold} attach="material" />
              </mesh>
            </group>
          ))}
        </group>
      </group>

      {/* speaker podiums */}
      {[
        { pos: PROSECUTOR_POS, color: "#6e2222", accent: "#d9534f" },
        { pos: ADVOCATE_POS, color: "#22356e", accent: "#4f79d9" },
      ].map(({ pos, color, accent }, i) => (
        <group key={i} position={[pos[0], 0, pos[2] + 0.95]}>
          <mesh position={[0, 0.58, 0]} castShadow receiveShadow>
            <boxGeometry args={[1.55, 1.16, 0.72]} />
            <meshStandardMaterial map={wall} color={color} roughness={0.7} />
          </mesh>
          <mesh position={[0, 1.2, 0.06]} rotation={[-0.32, 0, 0]} castShadow>
            <boxGeometry args={[1.72, 0.1, 0.86]} />
            <meshStandardMaterial color="#6b4326" roughness={0.5} />
          </mesh>
          <mesh position={[0, 0.72, 0.375]}>
            <boxGeometry args={[1.2, 0.28, 0.02]} />
            <meshStandardMaterial color={accent} emissive={accent} emissiveIntensity={0.35} />
          </mesh>
          <mesh position={[0, 1.28, 0.25]}>
            <boxGeometry args={[0.5, 0.035, 0.36]} />
            <meshStandardMaterial color="#e8e2d4" roughness={0.9} />
          </mesh>
        </group>
      ))}

      {/* witness benches with backrest + legs */}
      {[0, 1].map((row) => (
        <group key={row} position={[0, 0, 3.35 + row * 1.7]}>
          <mesh position={[0, 0.46, 0]} castShadow receiveShadow>
            <boxGeometry args={[9.6, 0.16, 0.62]} />
            <meshStandardMaterial map={wall} color="#7b5334" roughness={0.7} />
          </mesh>
          <mesh position={[0, 0.78, -0.26]} castShadow>
            <boxGeometry args={[9.6, 0.62, 0.1]} />
            <meshStandardMaterial color="#6a4527" roughness={0.7} />
          </mesh>
          {[-4.4, -2.2, 0, 2.2, 4.4].map((x) => (
            <mesh key={x} position={[x, 0.22, 0]} castShadow>
              <boxGeometry args={[0.14, 0.45, 0.5]} />
              <meshStandardMaterial color="#4d3119" roughness={0.8} />
            </mesh>
          ))}
        </group>
      ))}

      {/* railing in front of the judge area */}
      <group position={[0, 0, -2.9]}>
        <mesh position={[0, 1.0, 0]} castShadow>
          <boxGeometry args={[11, 0.11, 0.11]} />
          <meshStandardMaterial color="#6b4326" roughness={0.55} />
        </mesh>
        <mesh position={[0, 0.62, 0]}>
          <boxGeometry args={[11, 0.08, 0.08]} />
          <meshStandardMaterial color="#6b4326" roughness={0.55} />
        </mesh>
        {[-5.2, -2.6, 0, 2.6, 5.2].map((x) => (
          <mesh key={x} position={[x, 0.5, 0]} castShadow>
            <boxGeometry args={[0.13, 1.0, 0.13]} />
            <meshStandardMaterial color="#7b5334" roughness={0.6} />
          </mesh>
        ))}
      </group>

      {/* bookshelf on the back wall */}
      <group position={[-8.2, 0, -7.05]}>
        <mesh position={[0, 2.4, 0]} castShadow>
          <boxGeometry args={[3.1, 4.8, 0.5]} />
          <meshStandardMaterial color="#4a2c15" roughness={0.8} />
        </mesh>
        {[0.6, 1.65, 2.7, 3.75].map((y) => (
          <group key={y}>
            <mesh position={[0, y, 0.12]}>
              <boxGeometry args={[2.85, 0.09, 0.42]} />
              <meshStandardMaterial color="#5c3a1e" roughness={0.8} />
            </mesh>
            {Array.from({ length: 9 }).map((_, i) => (
              <mesh key={i} position={[-1.25 + i * 0.31, y + 0.32, 0.12]} castShadow>
                <boxGeometry args={[0.22, 0.52 + ((i * 7) % 5) * 0.035, 0.3]} />
                <meshStandardMaterial color={bookColors[i % bookColors.length]} roughness={0.85} />
              </mesh>
            ))}
          </group>
        ))}
      </group>

      {/* wall clock */}
      <group position={[8.2, 4.6, -7.15]}>
        <mesh castShadow>
          <cylinderGeometry args={[0.85, 0.85, 0.16, 28]} />
          <meshStandardMaterial color="#3b2412" roughness={0.55} />
        </mesh>
        <mesh position={[0, 0, 0.1]}>
          <cylinderGeometry args={[0.72, 0.72, 0.04, 28]} />
          <meshStandardMaterial color="#efe4cb" roughness={0.85} />
        </mesh>
        <mesh position={[0, 0.22, 0.14]}>
          <boxGeometry args={[0.055, 0.44, 0.02]} />
          <meshStandardMaterial color="#2b1a0c" />
        </mesh>
        <mesh position={[0.2, -0.06, 0.14]} rotation={[0, 0, -1.1]}>
          <boxGeometry args={[0.05, 0.56, 0.02]} />
          <meshStandardMaterial color="#2b1a0c" />
        </mesh>
      </group>

      {/* audience benches behind witnesses */}
      {[6.4, 7.0].map((z, i) => (
        <group key={i} position={[0, 0, z]}>
          <mesh position={[0, 0.42, 0]} castShadow>
            <boxGeometry args={[16, 0.14, 0.55]} />
            <meshStandardMaterial color="#5c4028" roughness={0.85} />
          </mesh>
          <mesh position={[0, 0.72, -0.22]}>
            <boxGeometry args={[16, 0.55, 0.1]} />
            <meshStandardMaterial color="#523a22" roughness={0.85} />
          </mesh>
        </group>
      ))}
    </group>
  );
}

/* ================= Character ================= */
function Puppet({
  player,
  position,
  isSpeaker,
  handUp,
  clickable,
  onClick,
  reactions,
}: {
  player: Player;
  position: Vec3;
  isSpeaker: boolean;
  handUp: boolean;
  clickable: boolean;
  onClick?: () => void;
  reactions: { id: string; emoji: string; age: number }[];
}) {
  const color = ROLE_COLORS[player.role ?? "witness"];
  const [hover, setHover] = useState(false);
  const group = useRef<THREE.Group>(null);
  const seed = useMemo(() => Math.random() * Math.PI * 2, []);
  const skin = "#f2cba6";

  useFrame(({ clock }) => {
    if (!group.current) return;
    const t = clock.getElapsedTime();
    const amp = isSpeaker && !player.muted ? 0.085 : 0.028;
    group.current.position.y = position[1] + Math.abs(Math.sin(t * (isSpeaker ? 5.2 : 1.9) + seed)) * amp;
    group.current.rotation.z = Math.sin(t * 1.4 + seed) * 0.035;
    if (isSpeaker) group.current.rotation.y = Math.sin(t * 1.1 + seed) * 0.16;
  });

  return (
    <group position={position}>
      <group
        onClick={(e) => {
          e.stopPropagation();
          if (clickable && onClick) onClick();
        }}
        onPointerOver={(e) => {
          e.stopPropagation();
          if (clickable) {
            setHover(true);
            document.body.style.cursor = "pointer";
          }
        }}
        onPointerOut={() => {
          setHover(false);
          document.body.style.cursor = "default";
        }}
      >
        {/* legs */}
        {[-0.17, 0.17].map((x) => (
          <group key={x} position={[x, 0, 0]}>
            <mesh position={[0, 0.32, 0]} castShadow>
              <capsuleGeometry args={[0.115, 0.42, 6, 12]} />
              <meshStandardMaterial color="#2b2b33" roughness={0.85} />
            </mesh>
            <mesh position={[0, 0.06, 0.09]} castShadow>
              <boxGeometry args={[0.22, 0.12, 0.34]} />
              <meshStandardMaterial color="#1c1c22" roughness={0.7} />
            </mesh>
          </group>
        ))}
        {/* torso */}
        <mesh position={[0, 0.86, 0]} castShadow>
          <capsuleGeometry args={[0.32, 0.5, 8, 18]} />
          <meshStandardMaterial
            color={hover ? "#ffffff" : color}
            emissive={hover ? color : isSpeaker ? color : "#000000"}
            emissiveIntensity={hover ? 0.55 : isSpeaker ? 0.16 : 0}
            roughness={0.6}
          />
        </mesh>
        {/* collar / role sash */}
        <mesh position={[0, 1.12, 0]} rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[0.24, 0.06, 10, 22]} />
          <meshStandardMaterial color="#f5f0e6" roughness={0.7} />
        </mesh>
        {/* arms */}
        {[-1, 1].map((s) => (
          <mesh key={s} position={[s * 0.42, 0.86, 0.02]} rotation={[0, 0, s * 0.42]} castShadow>
            <capsuleGeometry args={[0.1, 0.44, 6, 12]} />
            <meshStandardMaterial color={hover ? "#ffffff" : color} roughness={0.65} />
          </mesh>
        ))}
        {/* head */}
        <mesh position={[0, 1.42, 0]} castShadow>
          <sphereGeometry args={[0.3, 26, 26]} />
          <meshStandardMaterial color={skin} roughness={0.8} />
        </mesh>
        {/* hair / role headgear */}
        {player.role === "judge" ? (
          <group position={[0, 1.56, 0]}>
            <mesh castShadow>
              <sphereGeometry args={[0.33, 20, 20, 0, Math.PI * 2, 0, Math.PI / 2]} />
              <meshStandardMaterial color="#e8e6e1" roughness={0.85} />
            </mesh>
            {[-0.3, 0.3].map((x) => (
              <mesh key={x} position={[x, -0.12, 0]} castShadow>
                <capsuleGeometry args={[0.1, 0.28, 6, 12]} />
                <meshStandardMaterial color="#e8e6e1" roughness={0.85} />
              </mesh>
            ))}
          </group>
        ) : (
          <mesh position={[0, 1.58, -0.04]} castShadow>
            <sphereGeometry args={[0.29, 20, 20, 0, Math.PI * 2, 0, Math.PI / 2]} />
            <meshStandardMaterial color={player.role === "prosecutor" ? "#2b2118" : player.role === "advocate" ? "#4b2f1c" : "#3b2b22"} roughness={0.9} />
          </mesh>
        )}
        {/* eyes */}
        {[-0.115, 0.115].map((x) => (
          <group key={x} position={[x, 1.47, 0.255]}>
            <mesh>
              <sphereGeometry args={[0.072, 14, 14]} />
              <meshStandardMaterial color="#ffffff" roughness={0.35} />
            </mesh>
            <mesh position={[0, 0, 0.055]}>
              <sphereGeometry args={[0.032, 10, 10]} />
              <meshStandardMaterial color="#22222a" roughness={0.3} />
            </mesh>
          </group>
        ))}
        {/* brows */}
        {[-0.115, 0.115].map((x) => (
          <mesh key={x} position={[x, 1.575, 0.26]} rotation={[0, 0, x > 0 ? -0.18 : 0.18]}>
            <boxGeometry args={[0.1, 0.022, 0.03]} />
            <meshStandardMaterial color="#3b2b22" />
          </mesh>
        ))}
        {/* mouth */}
        {player.muted ? (
          <group position={[0, 1.32, 0.27]}>
            <mesh rotation={[0.18, 0, 0.55]}>
              <boxGeometry args={[0.2, 0.032, 0.03]} />
              <meshStandardMaterial color="#7f1d1d" />
            </mesh>
            <mesh rotation={[0.18, 0, -0.55]}>
              <boxGeometry args={[0.2, 0.032, 0.03]} />
              <meshStandardMaterial color="#7f1d1d" />
            </mesh>
          </group>
        ) : (
          <mesh position={[0, 1.31, 0.262]}>
            <sphereGeometry args={isSpeaker ? [0.075, 12, 12] : [0.045, 12, 12]} />
            <meshStandardMaterial color="#5b2333" roughness={0.5} />
          </mesh>
        )}
      </group>

      {/* speaker ring */}
      {isSpeaker && (
        <mesh position={[0, 0.035, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[0.52, 0.72, 42]} />
          <meshBasicMaterial color="#fbbf24" transparent opacity={0.92} />
        </mesh>
      )}
      {player.muted && (
        <mesh position={[0, 0.03, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[0.5, 0.62, 32]} />
          <meshBasicMaterial color="#dc2626" transparent opacity={0.8} />
        </mesh>
      )}

      {/* floating reactions */}
      {reactions.map((r, i) => (
        <Html key={r.id} position={[-0.5 + i * 0.35, 2.15 + r.age * 0.75, 0]} center distanceFactor={9}>
          <div
            style={{
              fontSize: 26,
              opacity: Math.max(0, 1 - r.age / 4),
              pointerEvents: "none",
              filter: "drop-shadow(0 3px 6px rgba(0,0,0,0.5))",
            }}
          >
            {r.emoji}
          </div>
        </Html>
      ))}

      {/* raised hand */}
      {handUp && (
        <Html position={[0.55, 1.95, 0]} center distanceFactor={8}>
          <div style={{ fontSize: 26, pointerEvents: "none", animation: "pulse 1.2s infinite" }}>✋</div>
        </Html>
      )}

      {/* label */}
      <Html position={[0, 2.12, 0]} center distanceFactor={10} occlude={false}>
        <div
          style={{
            background: "rgba(12,10,22,0.82)",
            border: `1px solid ${color}`,
            color: "white",
            padding: "3px 10px",
            borderRadius: 9,
            fontSize: 12,
            whiteSpace: "nowrap",
            textAlign: "center",
            fontFamily: "sans-serif",
            pointerEvents: "none",
            boxShadow: "0 4px 14px rgba(0,0,0,0.45)",
          }}
        >
          <div style={{ fontWeight: 700 }}>
            {player.muted ? "🔇 " : isSpeaker ? "🎙️ " : ""}
            {player.name}
          </div>
          <div style={{ color, fontSize: 10, letterSpacing: 1 }}>
            {ROLE_LABELS[player.role ?? "witness"].toUpperCase()}
          </div>
        </div>
      </Html>
    </group>
  );
}

/* ================= Gavel ================= */
function Gavel({
  state,
  positions,
}: {
  state: RoomState;
  positions: Map<string, Vec3>;
}) {
  const group = useRef<THREE.Group>(null);
  const animRef = useRef<{ start: number; target: THREE.Vector3 } | null>(null);
  const lastHitT = useRef<number>(0);
  const hit = state.lastHit;

  if (hit && hit.t !== lastHitT.current) {
    lastHitT.current = hit.t;
    const target =
      hit.kind === "button"
        ? new THREE.Vector3(...BUTTON_POS).add(new THREE.Vector3(0, 0.3, 0))
        : (() => {
            const p = positions.get(hit.targetId);
            return p ? new THREE.Vector3(p[0], p[1] + 1.75, p[2]) : null;
          })();
    if (target) animRef.current = { start: performance.now(), target };
  }

  useFrame(() => {
    const g = group.current;
    if (!g) return;
    const rest = new THREE.Vector3(...GAVEL_REST);
    const anim = animRef.current;
    if (!anim) {
      g.position.lerp(rest, 0.1);
      g.rotation.z = THREE.MathUtils.lerp(g.rotation.z, 0.55, 0.1);
      return;
    }
    const el = (performance.now() - anim.start) / 1000;
    const DUR = 1.05;
    if (el > DUR) {
      animRef.current = null;
      return;
    }
    if (el < 0.38) {
      const k = el / 0.38;
      g.position.lerpVectors(rest, anim.target, k);
      g.position.y += Math.sin(k * Math.PI) * 1.25;
      g.rotation.z = 0.55 - k * 0.35;
    } else if (el < 0.58) {
      const k = (el - 0.38) / 0.2;
      g.position.copy(anim.target);
      g.position.y -= Math.sin(k * Math.PI) * 0.5;
      g.rotation.z = 0.2 - Math.sin(k * Math.PI) * 1.15;
    } else {
      const k = (el - 0.58) / 0.47;
      g.position.lerpVectors(anim.target, rest, k);
      g.rotation.z = THREE.MathUtils.lerp(0.2, 0.55, k);
    }
  });

  return (
    <group ref={group} position={GAVEL_REST} rotation={[0, 0, 0.55]}>
      <mesh position={[0, -0.3, 0]} castShadow>
        <cylinderGeometry args={[0.038, 0.052, 0.66, 12]} />
        <meshStandardMaterial color="#8b5a2b" roughness={0.6} />
      </mesh>
      <mesh position={[0, -0.62, 0]}>
        <cylinderGeometry args={[0.055, 0.06, 0.08, 12]} />
        <meshStandardMaterial color="#c9a227" metalness={0.8} roughness={0.35} />
      </mesh>
      <mesh position={[0, 0.11, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
        <cylinderGeometry args={[0.125, 0.125, 0.38, 18]} />
        <meshStandardMaterial color="#5c3a1e" roughness={0.55} />
      </mesh>
      {[-0.19, 0.19].map((x) => (
        <mesh key={x} position={[x, 0.11, 0]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.135, 0.135, 0.035, 18]} />
          <meshStandardMaterial color="#3b2412" roughness={0.5} />
        </mesh>
      ))}
    </group>
  );
}

/* ================= Red "give floor" button ================= */
function FloorButton({ clickable, onClick }: { clickable: boolean; onClick: () => void }) {
  const [hover, setHover] = useState(false);
  return (
    <group
      position={BUTTON_POS}
      onClick={(e) => {
        e.stopPropagation();
        if (clickable) onClick();
      }}
      onPointerOver={(e) => {
        e.stopPropagation();
        if (clickable) {
          setHover(true);
          document.body.style.cursor = "pointer";
        }
      }}
      onPointerOut={() => {
        setHover(false);
        document.body.style.cursor = "default";
      }}
    >
      <mesh castShadow>
        <cylinderGeometry args={[0.26, 0.3, 0.1, 24]} />
        <meshStandardMaterial color="#8a8f98" metalness={0.75} roughness={0.35} />
      </mesh>
      <mesh position={[0, 0.09, 0]}>
        <sphereGeometry args={[0.19, 22, 22, 0, Math.PI * 2, 0, Math.PI / 2]} />
        <meshStandardMaterial
          color="#ef4444"
          emissive="#ef4444"
          emissiveIntensity={hover ? 1.1 : 0.42}
          roughness={0.35}
        />
      </mesh>
      <mesh position={[0, 0.005, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[0.3, 0.36, 26]} />
        <meshBasicMaterial color="#c9a227" />
      </mesh>
      <Html position={[0, 0.52, 0]} center distanceFactor={8}>
        <div
          style={{
            color: "#ffd7d7",
            fontSize: 11,
            fontFamily: "sans-serif",
            whiteSpace: "nowrap",
            pointerEvents: "none",
            textShadow: "0 1px 3px black",
            letterSpacing: 1,
          }}
        >
          🔔 СЛОВО
        </div>
      </Html>
    </group>
  );
}

/* ================= Scene ================= */
function SceneContents({ state, myId, firstPerson, onHammer, onButton }: Props) {
  const me = state.players.find((p) => p.id === myId);
  const isJudge = me?.role === "judge";
  const positions = useMemo(() => playerPositions(state.players), [state.players]);
  const now = Date.now();

  const reactionsByPlayer = useMemo(() => {
    const map = new Map<string, { id: string; emoji: string; age: number }[]>();
    for (const r of state.reactions) {
      const age = (now - r.t) / 1000;
      if (age > 4.5) continue;
      const list = map.get(r.playerId) || [];
      list.push({ id: r.id, emoji: r.emoji, age });
      map.set(r.playerId, list);
    }
    return map;
  }, [state.reactions, now]);

  const myPos = positions.get(myId) ?? [0, 0, 4];
  const spawn: Vec3 = [myPos[0], 1.72, myPos[2]];

  return (
    <>
      <color attach="background" args={["#1a1226"]} />
      <fog attach="fog" args={["#1a1226", 22, 42]} />
      <ambientLight intensity={0.42} />
      <hemisphereLight args={["#ffe6c4", "#2a1a12", 0.5]} />
      <directionalLight
        position={[7, 11, 7]}
        intensity={1.35}
        castShadow
        shadow-mapSize={[1024, 1024]}
        shadow-camera-left={-14}
        shadow-camera-right={14}
        shadow-camera-top={12}
        shadow-camera-bottom={-12}
      />
      <pointLight position={[-6, 5, 3]} intensity={16} distance={22} color="#ffcf96" />

      <Courtroom />
      <Gavel state={state} positions={positions} />
      <FloorButton clickable={isJudge && state.phase === "trial" && !state.onBreak} onClick={onButton} />

      {state.players.map((p) => {
        const pos = positions.get(p.id);
        if (!pos) return null;
        return (
          <Puppet
            key={p.id}
            player={p}
            position={pos}
            isSpeaker={state.speakerId === p.id && state.phase === "trial" && !state.onBreak}
            handUp={state.handsUp.includes(p.id)}
            clickable={isJudge && p.id !== myId && state.phase === "trial"}
            onClick={() => onHammer(p.id)}
            reactions={reactionsByPlayer.get(p.id) || []}
          />
        );
      })}

      <FirstPerson enabled={firstPerson} spawn={spawn} />
      {!firstPerson && (
        <OrbitControls
          target={[0, 1.5, -1.6]}
          minDistance={4}
          maxDistance={18}
          maxPolarAngle={Math.PI / 2.05}
          enablePan={false}
          autoRotate={false}
        />
      )}
    </>
  );
}

export default function CourtScene(props: Props) {
  return (
    <Canvas
      shadows
      camera={{ position: [0, 6.2, 11.5], fov: 52 }}
      gl={{ antialias: true }}
      dpr={[1, 1.75]}
    >
      <Suspense fallback={null}>
        <SceneContents {...props} />
      </Suspense>
    </Canvas>
  );
}

export { Textures };
