import {
  pgTable,
  serial,
  text,
  jsonb,
  timestamp,
  index,
} from "drizzle-orm/pg-core";

export const rooms = pgTable("rooms", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  state: jsonb("state").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const signals = pgTable(
  "signals",
  {
    id: serial("id").primaryKey(),
    roomCode: text("room_code").notNull(),
    fromId: text("from_id").notNull(),
    toId: text("to_id").notNull(),
    kind: text("kind").notNull(), // offer | answer | ice
    payload: jsonb("payload").notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (t) => [index("signals_room_to_idx").on(t.roomCode, t.toId)]
);

export const cases = pgTable("cases", {
  id: serial("id").primaryKey(),
  roomCode: text("room_code").notNull(),
  topic: text("topic").notNull(),
  verdict: text("verdict").notNull(),
  players: jsonb("players").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
